clear global;
clear;
clc;
load detector_5_500_5_300_1
global p;
p = parrot  
cameraObj=camera(p)
preview(cameraObj)
takeoff(p);
%moveup(p,15);
%moveleft(p,2);
flap=1;
while flap==1
    [img,ts]=snapshot(cameraObj);
    if isempty(img)==0
         [bboxes,score,label]=detect(detector,img);
         bboxes

        if isempty(bboxes)==1
            movedown(p,1,0.1);
        else
            detectedImg=insertShape(img,'rectangle',bboxes,'Color','blue','LineWidth',3);
            figure(1);
            imshow(detectedImg)

              LR=(round(((bboxes(1,1)+bboxes(1,3)/2)-428)/5.94)) % 公尺
              FB=(round(((bboxes(1,2)+bboxes(1,4)/2)-240)/5.16)) % 公尺

               
                if bboxes(3)*bboxes(4) >= 86800
                    flap=0;
                end
              
              if LR > 0
                if  78>=LR && LR>71
                     speed = 0.03;
                     moveright(p,6,speed);
                elseif 71>=LR && LR>58
                     speed = 0.03;
                     moveright(p,5,speed);     
                elseif 58>=LR && LR>45
                     speed = 0.03;
                     moveright(p,4,speed);
                elseif 45>=LR && LR>32
                    speed = 0.03;
                    moveright(p,3,speed);
                elseif 32>=LR && LR>19
                    speed = 0.03;
                    moveright(p,2,speed);
                elseif 19>=LR && LR>6
                    speed = 0.03;
                    moveright(p,1,speed);
                elseif 6>LR && LR>0
                     if FB > 0
                        if  58>=FB && FB>45
                            speed = 0.03;
                            moveback(p,4,speed);
                        elseif 45>=FB && FB>32
                            speed = 0.03;
                            moveback(p,3,speed);     
                        elseif 32>=FB && FB>19
                            speed = 0.03;
                            moveback(p,2,speed);
                        elseif 19>=FB && FB>6
                            speed = 0.03;
                            moveback(p,1,speed);
                        else
                            speed=0.03;
                            movedown(p,2,speed);
                        end
                     else 
                        if  -58<=FB && FB<-45
                            speed = 0.03;
                            moveforward(p,4,speed);
                        elseif -45<=FB && FB<-32
                            speed = 0.03;
                            moveforward(p,3,speed);     
                        elseif -32<=FB && FB<-19
                            speed = 0.03;
                            moveforward(p,2,speed);
                        elseif -19<=FB && FB<-6
                            speed = 0.03;
                            moveforward(p,1,speed);
                        else
                            speed=0.03;
                            movedown(p,2,speed);
                        end
                     end
                end
              else 
                if  -78<=LR && LR<-71
                    speed = 0.03;
                    moveleft(p,6,speed);
                elseif -71<=LR && LR<-58
                    speed = 0.03;
                    moveleft(p,5,speed);                
                elseif -58<=LR && LR<-45
                    speed = 0.03;
                    moveleft(p,4,speed);
                elseif -45<=LR && LR<-32
                    speed = 0.03;
                    moveleft(p,3,speed);
                elseif -32<=LR && LR<-19
                    speed = 0.03;
                    moveleft(p,2,speed);
                elseif -19<=LR && LR<-6
                    speed = 0.03;
                    moveleft(p,1,speed);  
                elseif -6<LR && LR<0
                     if FB > 0
                        if  58>=FB && FB>45
                            speed = 0.03;
                            moveback(p,4,speed);
                        elseif 45>=FB && FB>32
                            speed = 0.03;
                            moveback(p,3,speed);     
                        elseif 32>=FB && FB>19
                            speed = 0.03;
                            moveback(p,2,speed);
                        elseif 19>=FB && FB>6
                            speed = 0.03;
                            moveback(p,1,speed);
                        else
                            speed=0.03;
                            movedown(p,2,speed);
                        end
                     else 
                        if  -58<=FB && FB<-45
                            speed = 0.03;
                            moveforward(p,4,speed);
                        elseif -45<=FB && FB<-32
                            speed = 0.03;
                            moveforward(p,3,speed);     
                        elseif -32<=FB && FB<-19
                            speed = 0.03;
                            moveforward(p,2,speed);
                        elseif -19<=FB && FB<-6
                            speed = 0.03;
                            moveforward(p,1,speed);
                        else
                            speed=0.03;
                            movedown(p,2,speed);
                        end
                     end
                 end          
              end
        end
    end
end
land(p);







