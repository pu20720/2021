clear;
p = parrot;
cameraObj=camera(p);
preview(cameraObj);
load detector;
% 
% addpath(pwd,'Annotation');
% addpath(pwd,'TrainingImage');
% 
% for i=1:10
%     A=xlsread([num2str(i),'.xml']);
%     imageFilename(i,:)={[num2str(i),'.jpg']};
%     bboxes(i,:)={[A(2) A(4) A(1)-A(2) A(3)-A(4)]};
% end
% 
% % 以datastore建立trainingData
% T=table(imageFilename,bboxes);
% imds=imageDatastore(T.imageFilename);
% blds=boxLabelDatastore(T(:,2:end)); 
% trainingData=combine(imds,blds);
% 
% 
% 
% lgraph=ssdLayers([600 600 3],1,'vgg16');
% 
% % Train SSD                           
% options=trainingOptions('rmsprop', ...   % 'rmsprop''adam''sgdm'
%     'MiniBatchSize',1, ....           
%     'Shuffle','every-epoch', ...
%     'MaxEpochs',1, ...              %500
%     'InitialLearnRate',1e-5, ...
%     'LearnRateSchedule','piecewise', ...
%     'LearnRateDropPeriod',3500, ...    
%     'LearnRateDropFactor',0.9, ...
%     'Verbose',1, ...
%     'ExecutionEnvironment','gpu');
% 
% [detector,info]=trainSSDObjectDetector(trainingData,lgraph,options);
% 
% % 繪訓練accuracy圖
% figure(1)
% plot(info.TrainingAccuracy)
% xlabel('Iteration')
% ylabel('Training Accuracy')
% 
% % 繪訓練loss圖
% figure(2)
% semilogy(info.TrainingLoss)
% xlabel('Iteration')
% ylabel('Training Loss')
% 

for i = 1:55
        figure(i);
        img=imread(int2str(i),'jpg');
        [bboxes,score,label]=detect(detector,img,'MiniBatchSize',32);

        [score,idx]=max(score);
        bboxes=bboxes(idx,:);
        A=sprintf('%s: (Confidence = %f)',label(idx),score);
        detectedImg=insertObjectAnnotation(img,'rectangle',bboxes,A);
        imshow(detectedImg);
end