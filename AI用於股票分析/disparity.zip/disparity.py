import pandas as pd 
import numpy as np

#26支太陽能股票代號
files = ['1538', '1717', '1735', '1802', '1809', '2308', '2342', '2367', '2426', '2434', '2481', '3016', '3073', '3268', '3532' , '3576', '3686', '3691', '3713', '4707', '5434', '5483', '6244', '6443', '8039', '8085']

def change(day, col):
    arr = []
    for i in range(day):
        number = round(((col[i] - col[i+1]) / col[i+1])*100, 2)
        arr.append(number)
        
    return arr  

def changeCompare(day, scope, delta):
    compareResult = []
    for i in range(0,len(files)):       #第一層for迴圈，代入第一支股票，ex:1538。
        closeA = []                     #宣告 closeA 為空串列，用來儲存第一支股票漲跌率的資訊。
        pathA = 'C:/stock/StockData/' + files[i] + '.csv'   #第一支股票檔案位置。
        stock = pd.read_csv(pathA)      #讀取第一支股票的csv檔回傳至stock
    
        for k in stock.Close:       # 爬取第一支股票的收盤價
            closeA.append(k)
        
        closeA = np.array(closeA)       #將爬取的收盤價資訊回傳至 closeA 串列
    
        closeA = change(day, closeA)     #呼叫 change() 函式計算第一支股票支漲跌率
        for j in range(0, len(files)):      #第二層for迴圈，代入第二支股票，ex:1717。
            if i==j:            #若帶入之第一支股票和第二支股票代號相同，則continue。
                continue
            else:               #其餘進行第二支股票漲跌率計算
                closeB = []
                pathB = 'C:/stock/StockData/' + files[j] + '.csv'
                stock = pd.read_csv(pathB)
    
                for k in stock.Close:
                    closeB.append(k)
                    
                closeB = np.array(closeB)
                    
                closeB = change(day, closeB)
                
                #宣告 a, b, c, d 四個變數，用來儲存兩支股票漲跌率之間關連性地象限值
                a=0
                b=0
                c=0
                d=0           
                
                #進行關聯性比對，計算象限值
                for x in range(scope):
                    if closeA[x]>0 and closeB[x+delta]>0:
                        a=a+1
                    elif closeA[x]<=0 and closeB[x+delta]>0:
                        b=b+1              
                    elif closeA[x]<=0 and closeB[x+delta]<=0:
                        c=c+1                
                    elif closeA[x]>0 and closeB[x+delta]<=0:
                        d=d+1
                
                up = round(a / (a + d),2)
                down =round( c / (b + c),2)
                
                if up >= 0.7 or down >= 0.7:
                    compareResult.append([files[i], files[j], a, b, c, d, up, down, scope]) 
                else:
                    continue
                
    return compareResult
                    
def universality(thirty, sixty, ninety, outputUp, outputDown):
    for i in range(len(ninety)):
        for j in range(len(sixty)):
            if ninety[i][0:2] == sixty[j][0:2]:
                for k in range(len(thirty)):
                    if ninety[i][0:2] == thirty[k][0:2]:
                        if ninety[i][6] >= 0.7:
                            outputUp.append(thirty[k])
                            outputUp.append(sixty[j])
                            outputUp.append(ninety[i])
                        else:
                            outputDown.append(thirty[k])
                            outputDown.append(sixty[j])    
                            outputDown.append(ninety[i])
                             
                    else:
                        continue
            
            else:
                continue
    
    
            
def integrate():
    outputFiles = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten']
    thirty = []
    sixty = []
    ninety = []
    
    
    for i in range(0,10):
        outputUp = []
        outputDown = []
        thirty = changeCompare(130, 30, i+1)
        sixty = changeCompare(160, 60, i+1)
        ninety = changeCompare(190, 90, i+1)
        
        
        
        pathUp = 'C:/specialTopic/disparity/disparity'+outputFiles[i]+'Output/disparity'+outputFiles[i]+'OutputUp.txt'
        pathDown = 'C:/specialTopic/disparity/disparity'+outputFiles[i]+'Output/disparity'+outputFiles[i]+'OutputDown.txt'
        
        universality(thirty, sixty, ninety, outputUp, outputDown)
        
        
        with open(pathUp, 'a') as fup:
            for i in range(len(outputUp)):
                print(outputUp[i], file=fup)
            
        with open(pathDown, 'a') as fdown:
            for i in range(len(outputDown)):
                print(outputDown[i], file=fdown)
        


integrate()