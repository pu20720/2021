vid=VideoReader('camera.mp4');
  numFrames = vid.NumberOfFrames;
  n=numFrames;
for i = 1:600:n  
   frames = read(vid,i);
   imwrite(frames,['.\' int2str(1), '.jpg']);
   
end 

