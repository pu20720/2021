function [bboxes,score,label] = run_ssd(img)
%#codegen

    persistent ssd_detector;
    
    if isempty(ssd_detector)
        ssd_detector = coder.loadDeepLearningNetwork('ssd_detector.mat');
    end
    
    [bboxes,score,label] = detect(ssd_detector,img);
end

