% clear;
addpath(pwd,'Annotation');
addpath(pwd,'TrainingImage');

for i=1:100
    A=xlsread([num2str(i),'.xml']);
    %disp(A);
    imageFilename(i,:)={[num2str(i),'.jpg']};
    bboxes(i,:)={[A(2) A(4) A(1)-A(2) A(3)-A(4)]};
end

% 以datastore建立trainingData
T=table(imageFilename,bboxes);
imds=imageDatastore(T.imageFilename);
blds=boxLabelDatastore(T(:,2:end));
trainingData=combine(imds,blds);


% lgraph=ssdLayers([300 300 3],1,'vgg16');
net = vgg16;
baseNetwork = layerGraph(net.Layers);
% lgraph_vgg16 = ssdLayers([300 300 3], 1, baseNetwork, {[72, 36; 36, 72], [72, 72; 144, 72; 72, 144]}, ["conv4_3", "conv5_3"]);
lgraph_vgg16 = ssdLayers([300 300 3], 1, baseNetwork, {[72, 36; 36, 72], [72, 72; 144, 72; 72, 144]}, ["conv4_3", "conv5_3"]);
%% 訓練SSD
% Train SSD
options=trainingOptions('rmsprop', ...
    'MiniBatchSize',5, ....
    'Shuffle','every-epoch', ...
    'MaxEpochs',115, ...
    'InitialLearnRate',1e-5, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',100, ...
    'LearnRateDropFactor',0.4, ...
    'Verbose',1, ...
    'ExecutionEnvironment','multi-gpu', ...
    'Plots','training-progress');
%sgdm
[detector,info]=trainSSDObjectDetector(trainingData,lgraph_vgg16,options);
%% Learning Accuracy 的圖表
% 繪訓練accuracy圖
figure('Name','訓練Accuracy圖','NumberTitle','off')
plot(info.TrainingAccuracy)
xlabel('Iteration')
ylabel('Training Accuracy')

%% Learning Loss 的圖片繪製
% 繪訓練loss圖
figure('Name','訓練Loss圖','NumberTitle','off')
semilogy(info.TrainingLoss)
xlabel('Iteration')
ylabel('Training Loss')

%% 測試SSD訓練結果

figure('Name','訓練測試圖','NumberTitle','off')
img=imread('6.jpg');
[bboxes,score,label]=detect(detector,img);

[score,idx]=max(score);
bboxes=bboxes(idx,:); 
% A=sprintf('%s: (Confidence = %f)',label(idx),score);
A=append(cellstr(label(idx)), ': (Confidence = ', num2str(score), ')');
detectedImg=insertObjectAnnotation(img,'rectangle',bboxes,A);
imshow(detectedImg);
   

