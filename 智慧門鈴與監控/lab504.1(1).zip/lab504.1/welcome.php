<html>

<head>

    <title>Realtime communication with PI</title>

    <link rel="stylesheet" href="style.css" />

</head>

<body>
    <div class="logout">
        <form class="form">
            <h1>即時畫面</h1>

            <div class="HP">

                <a href="http://10.3.141.153/"><input class="btn" type="button" onclick="window.location.herf" value="點擊查看" name="submit"></a>

            </div><br><br>
            <?php

            echo "<h2>若需返回首頁請<a href='logout.php' class=''>點此登出</a></h2>";
            ?>


        </form>

    </div>

</body>

</html>