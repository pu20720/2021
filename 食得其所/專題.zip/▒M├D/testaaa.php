<?php
	session_start(); //啟動 session
?>
<!DOCTYPE html>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC|Open+Sans&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<script src="https://kit.fontawesome.com/68f8681dba.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="css/style.css">
		<title>K.O. Party - Best Party in Hong Kong</title>
    <script type="text/javascript" src="order.js"></script>
	</head>
		<style>
		.buttona {
			font-size:45px;
		}
		*,
*:before,
*:after {
    box-sizing: border-box;
}

img {
    max-width: 100%;
    height: auto;
}

.clearfix:after {
    content: '';
    display: table;
    clear: both;
}

body {
    line-height: 1.6;
}

.wrap {
    max-width:5000px;
    margin: 0 auto;
    padding: 1em;
}

h2 {
    font-size: 20px;
    font-weight: 600;
    padding-bottom: 1em;
}

.news li {
    float: left;
    width: 29.33333%;
    margin: 2%;
}

@media(max-width:768px) {
    .news li {
        width: 46%;/*50%記得扣除768px以上的左右margin共4%*/
    }
}

@media(max-width:569px) {
    .news li {
        width: 96%;/*100%記得扣除768px以上的左右margin共4%*/
    }
}
dl{
	list-style-type:none;
	margin:0px;
}
.text_box {
width: 60px;
height: 43px;
text-align: center;
border: 1px solid #7B7B7B;
}
.box {
padding: 30px;
}
.one{
font-size: 20px;
}/* 加載csshover3.htc，解決IE6沒有li:hover擬類的問題 */
* html body {
	behavior:url("csshover3.htc");
}
/* ---------- 大小與定位 ---------- */
#menu {
	/* 選單大小 */
	width:1480px;
	height:50px;
}
#menu ul {
	/* 取消ul樣式符號 */
	list-style-type:none;
	/* 重設ul邊界與留白為零 */
	margin:0;
	padding:0;
	/* 內有浮動元件時，需設overflow才會自動調整大小 */
	overflow:auto;
}
* html #menu ul {
	/* 解決IE6不理overflow問題，直接指定高度 */
	height:50px;
}
#menu ul li {
	/* 利用float讓第一層li水平排列 */
	float:left;
}
/* 解決IE6條列式餘白問題*/
* html #menu ul li {
	display:inline;
}
#menu ul li a {
	/* 將a改為區塊元件，以便指定寬高 */
	display:block;
	/* 這邊也要設float，否則IE6會以100%寬度顯示 */
	float:left;
	/* 固定高度 */
	height:50px;
	width: 370px;
}
#menu ul li ul {
	/* 讓第二層ul跳脫文件流以利定位 */
	position:absolute;
	/* 固定寬度 */
	width:370px;
	/* 避免出現捲軸 */
	overflow:visible;
	/* 讓ul與母階層li相同位置 */
	clear:left;
	margin-top: 50px;
	margin-right: 0;
	margin-bottom: 0;
	margin-left: 0;
}
/* 修正IE7絕對定位差異 */
*:first-child+html #menu ul li ul {
	margin-top:0;
}
/* 修正IE6絕對定位差異 */
* html #menu ul li ul {
	margin-top:0;
}
#menu ul li ul li {
	/* 覆寫繼承自第一層的浮動設定 */
	float:none;
	text-align: center;
}
#menu ul li ul li a {
	/* 覆寫繼承自第一層的浮動設定 */
	float:none;
	width: 100%;/* 註：display、height、padding繼承第一層的設定 */
}
#menu ul li ul li ul {
	margin-top: -50px;
	margin-right: 0;
	margin-bottom: 0;
	margin-left: 412.5px;
	width: 100%;
}
/* 修正IE7絕對定位差異 */
*:first-child+html #menu ul li ul li ul {
	margin-top:100px;
}
#menu ul li ul li ul li {
/* width、float繼承第二層，免設定 */
}
#menu ul li ul li ul li a {
/* width、float繼承第二層，免設定 */
}
/* ---------- 隱藏與顯示階層 ---------- */
#menu ul li ul {
	/* 預先隱藏第二層 */
	visibility:hidden;
}
#menu ul li:hover ul {
	/* 觸動第一層時，顯示第二層 */
	visibility:visible;
}
#menu ul li:hover ul li ul {
	/* 顯示第二層時，隱藏第三層，避免同時彈出 */
	visibility:hidden;
}
#menu ul li ul li:hover ul {
	/* 觸動第二層時，顯示第三層 */
	visibility:visible;
}
#menu ul li ul li:hover ul li ul {
	/* 顯示第三層時，隱藏第四層，避免同時彈出 */
	visibility:hidden;
}
#menu ul li ul li ul li:hover ul {
	/* 觸動第三層時，顯示第四層 */
	visibility:visible;
}
/* ---------- 以下為美化用，非必需 ---------- */


/* 預設字體 */
#menu {
	font-size:35px;
	font-family:Arial, Helvetica, sans-serif;
}
/* 第一層ul背景色彩與邊框 */
#menu ul {
	background:#9e9e9e;
}
/* 第一層a字型 */
#menu ul li a {
	color:#fff;
	text-decoration:none;
	line-height: 50px;
}
/*第二層ul背景色彩與邊框  */
#menu ul li ul {
	background:#efefef;
}
/* 第二層a字型 */
#menu ul li ul li a {
	font-size:35px;
	color:#333333;
	text-decoration:none;
}
/* 觸動第一層li時，改變背景色 */
#menu ul li:hover, #menu ul li a:hover {
	background:#efefef;
}
#menu ul li:hover a {
	color:#333333;
}
/* 觸動第二層以上li時改變背景色 */
#menu ul li ul li:hover, #menu ul li ul li a:hover {
	background:#dfdfdf;
}
</style>
<body>
	<?php
		//如果有 $_SESSION['is_login'] 這變數，以及 $_SESSION['is_login'] 為 true，就是已經登入了
		if(isset($_SESSION['is_login']) && $_SESSION['is_login']):
	?>
        <header>
				<div style="background-image:url('images/bc.jpg');">
				<nav class="navbar navbar-expand-lg navbar-light">
				  <a class="navbar-brand" href="menuback.php"><img src='images/goldlogo.png' width='100'></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent" style="font-size: 30px">
				    <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="menuback.php"><font color="#ffffff">首頁</font></a>
				      </li>
				      <li class="nav-item">
                <a class="nav-link" href="order.php"><font color="#ffffff">點餐</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="faq.html"><font color="#ffffff">查詢</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="logout.php"><font color="#ffffff">登出</font></a>
				      </li>
				    </ul>

				  </div>
				</nav>
			</div>
        </header>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
				</div>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg');">
				</div>
				<div class="wrap" style="background-image:url('images/bc1.jpg');">
					<div class="row">
					<div class='col-md-12 text-center'>
						<div id="menu">
					  <ul>
							<li><a href="#">卡布奇諾</a>
								<ul>
				        <li> <a href="#White_Meat">咖啡</a>
				          <ul>
				            <li><a href="#Chicken">黑系列 冠軍特調美式</a></li>
				            <li><a href="#Duck">黑系列 冠軍特調拿鐵</a></li>
				            <li><a href="#Fish">黑沃風味拿鐵-榛果</a></li>
										<li><a href="#Fish">黑沃風味拿鐵-玫瑰</a></li>
										<li><a href="#Fish">黑沃風味拿鐵-黑糖</a></li>
										<li><a href="#Fish">卡布奇諾</a></li>
										<li><a href="#Fish">檸檬咖啡</a></li>
										<li><a href="#Fish">紅茶厚奶</a></li>
										<li><a href="#Fish">黑糖厚奶</a></li>
										<li><a href="#Fish">抹茶布蕾厚奶</a></li>
										<li><a href="#Fish">可可布蕾厚奶</a></li>
										<li><a href="#Fish">手作金萱烏龍</a></li>
				          </ul>
				        </li>
				        <li> <a href="#Red_Meat">主食</a>
									<ul>
				            <li><a href="#Chicken">奶油雞肉焗管麵</a></li>
				            <li><a href="#Duck">火腿麥香三明治</a></li>
				            <li><a href="#Fish">烤腿排風味三明治</a></li>
										<li><a href="#Fish">鮪魚佛卡夏</a></li>
										<li><a href="#Fish">火腿貝果</a></li>
										<li><a href="#Fish">墨西哥辣椒豬肉炊米堡</a></li>
										<li><a href="#Fish">墨西哥辣椒牛肉堡</a></li>
										<li><a href="#Fish">鮪魚玉米義式磚壓三明治</a></li>
										<li><a href="#Fish">培根口袋歐姆蛋</a></li>
										<li><a href="#Fish">泰式香茅烤雞腿佐綠香米飯</a></li>
										<li><a href="#Fish">雙梨黃金咖哩雞飯</a></li>
										<li><a href="#Fish">美墨烤雞翅肉醬麵</a></li>
				          </ul>
				        </li>
								<li> <a href="#Red_Meat">甜點</a>
									<ul>
				            <li><a href="#Chicken">栗子三重奏蛋糕</a></li>
				            <li><a href="#Duck">水果布蕾香緹蛋糕</a></li>
				            <li><a href="#Fish">紅心芭樂青蘋蛋糕</a></li>
										<li><a href="#Fish">柚香伯爵塔</a></li>
										<li><a href="#Fish">法式黑森林蛋糕</a></li>
										<li><a href="#Fish">經典千層薄餅</a></li>
										<li><a href="#Fish">可可伯爵薄餅</a></li>
										<li><a href="#Fish">經典起司蛋糕</a></li>
										<li><a href="#Fish">咖啡巧克力松露蛋糕</a></li>
										<li><a href="#Fish">檸檬塔</a></li>
										<li><a href="#Fish">法式千層薄餅</a></li>
										<li><a href="#Fish">岩漿巧克力蛋糕</a></li>
				          </ul>
				        </li>
				      	</ul>
					    </li>
					    <li> <a href="#">早上</a>
					      <ul>
					        <li><a href="#">早上</a></li>
					        <li><a href="#">中午</a></li>
					        <li><a href="#">下午</a></li>
					        <li><a href="#">晚上</a></li>
					      </ul>
					    </li>
							<li> <a href="#">陰天</a>
					      <ul>
					        <li><a href="#">晴天</a></li>
					        <li><a href="#">陰天</a></li>
					        <li><a href="#">雨天</a></li>
					      </ul>
					    </li>
							<li> <a href="#">女</a>
					      <ul>
					        <li><a href="#">男</a></li>
					        <li><a href="#">女</a></li>
					      </ul>
					    </li>
					  </ul>
					</div>
	 				</div>
				</div>
			</div>
			<center>
				<div style="border:0px;border-color:#000000;padding:20px;background-image:url('images/bc1.jpg');">
				</div>
			<div style="border:0px;border-color:#000000;padding:200px;background-image:url('images/bc1.jpg');">
			</div>
			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
			</div>
		</center>
	</dl>
</div>
</div>
				<?php else:?>
					<?php
					//沒有登入
					//使用php header 來轉址
					header('Location: menufront.php');
					?>
				<?php endif;?>
			</body>
			<footer style="background-image:url('images/bc.jpg');">
				<br>
				<div class="container">
					<div class='row'>
					<div class='col-md-3 text-left'>
					</div>
					<div class='col-md-6 text-center'>
						<br>
						<br>
						<font color="#ffffff"><h5>𝒲𝒽𝑒𝓇𝑒 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒸💗𝒻𝒻𝑒𝑒, 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒶 𝓌𝒶𝓎.</h5></font>
					</div>
					<div class='col-md-3 text-left' style="font-size:15px">
						<center>
						<a class="navbar-brand" href="menuback.php"><img src='images/ig.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/fb.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/twitter.jpg' width='44'></a>
						<p><br><font color="#ffffff">403台中市西區公益路147號<br>
						Phone: (04)576-2276</font>
					  </p>
						</center>
					</div>
					</div>
				</div>
				<br>
			</footer>
</html>
