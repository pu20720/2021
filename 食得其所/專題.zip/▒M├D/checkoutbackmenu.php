<?php
	session_start(); //啟動 session
?>
<?php

$link = mysqli_connect("localhost","root",
                       "ioioio330","test")
        or die("無法開啟MySQL資料庫連接!<br/>");


$onlinetable = $_POST["onlinetable"];

$sql = "DELETE FROM drinkless WHERE onlinetable='$onlinetable'";
if(mysqli_query($link, $sql)){
} else{
}

if($_POST["onlinetable"]!=null){//時間
	$result = mysqli_query($link,"SELECT * FROM drinkless where onlinetable='$onlinetable'");
	$add = mysqli_query($link,"SELECT SUM(cups) FROM drinkless where onlinetable='$onlinetable'");
	$addmoney = mysqli_query($link,"SELECT SUM(total) FROM drinkless where onlinetable='$onlinetable'");
	mysqli_query($link, 'SET NAMES utf8');
}
else{
$result = mysqli_query($link,"SELECT * FROM drinkless ");
$add = mysqli_query($link,"SELECT SUM(cups) FROM drinkless");
$addmoney = mysqli_query($link,"SELECT SUM(total) FROM drinkless");
mysqli_query($link, 'SET NAMES utf8');
}


?>
<?php
	session_start(); //啟動 session
?>
<?php header('refresh: 5;url="menuback.php"') ?>
<!DOCTYPE html>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC|Open+Sans&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<script src="https://kit.fontawesome.com/68f8681dba.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="icon" href="images/goldlogonew.png" type="image/x-icon" />
		<title>卡洛斯咖啡</title>
    <script type="text/javascript" src="order.js"></script>
	</head>
		<style>
		.buttona {
			font-size:45px;
		}
		*,
*:before,
*:after {
    box-sizing: border-box;
}

img {
    max-width: 100%;
    height: auto;
}

.clearfix:after {
    content: '';
    display: table;
    clear: both;
}

body {
    line-height: 1.6;
}

.wrap {
    max-width:5000px;
    margin: 0 auto;
    padding: 1em;
}

h2 {
    font-size: 20px;
    font-weight: 600;
    padding-bottom: 1em;
}

.news li {
    float: left;
    width: 29.33333%;
    margin: 2%;
}

@media(max-width:768px) {
    .news li {
        width: 46%;/*50%記得扣除768px以上的左右margin共4%*/
    }
}

@media(max-width:569px) {
    .news li {
        width: 96%;/*100%記得扣除768px以上的左右margin共4%*/
    }
}
dl{
	list-style-type:none;
	margin:0px;
}
.text_box {
width: 60px;
height: 43px;
text-align: center;
border: 1px solid #7B7B7B;
}
.box {
padding: 30px;
}
.one{
font-size: 20px;
}
.new1{
font-size: 32px;
}
</style>
<body>
	<?php
		//如果有 $_SESSION['is_login'] 這變數，以及 $_SESSION['is_login'] 為 true，就是已經登入了
		if(isset($_SESSION['is_login']) && $_SESSION['is_login']):
	?>
        <header>
				<div style="background-image:url('images/bc.jpg');">
				<nav class="navbar navbar-expand-lg navbar-light">
				  <a class="navbar-brand" href="menuback.php"><img src='images/goldlogonew.png' width='100'></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent" style="font-size: 30px">
				    <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="menuback.php"><font color="#ffffff">首頁</font></a>
				      </li>
				      <li class="nav-item">
                <a class="nav-link" href="order.php"><font color="#ffffff">點餐</font></a>
				      </li>
							<li class="nav-item">
                <a class="nav-link" href="searchbackonline.php"><font color="#ffffff">線上訂單</font></a>
							</li>
							<li class="nav-item">
                <a class="nav-link" href="checkout.php"><font color="#ffffff">結帳</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="searchtotal.php"><font color="#ffffff">查詢</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="logout.php"><font color="#ffffff">登出</font></a>
				      </li>
				    </ul>

				  </div>
				</nav>
			</div>
        </header>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
				</div>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg')">
				</div>
				<body>
        <div class="wrap">
  	        <div class="content">
							<dl class="news clearfix">
								<li>
										<img src="images/h11.jpg" alt="">
										<div class="new1">手作教室</div>
										<p>
											我們提供安全且舒適的環境，讓您和您的小孩享受親自動手製作美食的過程。
										</p>
								</li>
								<li>
										<img src="images/l22.jpg" alt="">
										<div class="new1">嚴選來源</div>
										<p>
												在提供美味的同時，我們也致力於把關食材的來源，以高標準自我要求，將每一個環節為您把關。
										</p>
								</li>
								<li>
										<img src="images/h22.jpg" alt="">
										<div class="new1">全面防疫</div>
										<p>
											店內同仁開啟一日工作之前皆確實量測體溫、消毒並配戴口罩，給顧客一個健康且安全的用餐環境。
										</p>
								</li>
								<li>
										<img src="images/l44.jpg" alt="">
										<div class="new1">舒適環境</div>
										<p>
												顧客是我們服務的動力。為表達對顧客的感激，我們提供高品質產品、優質服務、整齊清潔且歡迎顧客的用餐環境。
										</p>
								</li>
									<li>
											<img src="images/h55.jpg" alt="">
											<div class="new1">環保愛地球</div>
											<p>
													美好滋味從講究食材開始。我們不斷努力於在地及全球找尋當季最好的食材，每一口都品嘗得到真材實料！
											</p>
									</li>
									<li>
											<img src="images/h66.jpg" alt="">
											<div class="new1">真誠態度</div>
											<p>
											 對顧客充滿熱情，用我們真誠的服務態度，換取客戶對我們的滿意程度。
											</p>
									</li>
							</dl>
  	        </div>
  	    </div>

  	     </body>
				<?php else:?>
					<?php
					//沒有登入
					//使用php header 來轉址
					header('Location: menufront.php');
					?>
				<?php endif;?>
			</body>
			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg')">
			</div>
			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
			</div>
			<footer>
				<div style="background-image:url('images/bc.jpg');">
				<br>
				<div class="container">
					<div class='row'>
					<div class='col-md-3 text-left'>
					</div>
					<div class='col-md-6 text-center'>
						<br>
						<br>
						<font color="#ffffff"><h5>𝒲𝒽𝑒𝓇𝑒 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒸💗𝒻𝒻𝑒𝑒, 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒶 𝓌𝒶𝓎.</h5></font>
					</div>
					<div class='col-md-3 text-left' style="font-size:15px">
						<center>
						<a class="navbar-brand" href="menuback.php"><img src='images/ig.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/fb.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/twitter.jpg' width='44'></a>
						<p><br><font color="#ffffff">403台中市西區公益路147號<br>
						Phone: (04)576-2276</font>
					  </p>
						</center>
					</div>
					</div>
				</div>
				<br>
			</div>
			</footer>
</html>
