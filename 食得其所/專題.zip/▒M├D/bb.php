<?php
	session_start(); //啟動 session
?>
<!DOCTYPE html>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC|Open+Sans&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<script src="https://kit.fontawesome.com/68f8681dba.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="css/style.css">
		<title>K.O. Party - Best Party in Hong Kong</title>
    <script type="text/javascript" src="order.js"></script>
	</head>
		<style>
		.buttona {
			font-size:45px;
		}
		*,
*:before,
*:after {
    box-sizing: border-box;
}

img {
    max-width: 100%;
    height: auto;
}

.clearfix:after {
    content: '';
    display: table;
    clear: both;
}

body {
    line-height: 1.6;
}

.wrap {
    max-width:5000px;
    margin: 0 auto;
    padding: 1em;
}

h2 {
    font-size: 20px;
    font-weight: 600;
    padding-bottom: 1em;
}

.news li {
    float: left;
    width: 29.33333%;
    margin: 2%;
}

@media(max-width:768px) {
    .news li {
        width: 46%;/*50%記得扣除768px以上的左右margin共4%*/
    }
}

@media(max-width:569px) {
    .news li {
        width: 96%;/*100%記得扣除768px以上的左右margin共4%*/
    }
}
dl{
	list-style-type:none;
	margin:0px;
}
.text_box {
width: 60px;
height: 43px;
text-align: center;
border: 1px solid #7B7B7B;
}
.box {
padding: 30px;
}
.one{
font-size: 20px;
}
</style>
<body>
	<?php
		//如果有 $_SESSION['is_login'] 這變數，以及 $_SESSION['is_login'] 為 true，就是已經登入了
		if(isset($_SESSION['is_login']) && $_SESSION['is_login']):
	?>
        <header>
				<div style="background-image:url('images/bc.jpg');">
				<nav class="navbar navbar-expand-lg navbar-light">
				  <a class="navbar-brand" href="menuback.php"><img src='images/goldlogo.png' width='100'></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent" style="font-size: 30px">
				    <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="menuback.php"><font color="#ffffff">首頁</font></a>
				      </li>
				      <li class="nav-item">
                <a class="nav-link" href="order.php"><font color="#ffffff">點餐</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="faq.html"><font color="#ffffff">查詢</font></a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link" href="logout.php"><font color="#ffffff">登出</font></a>
				      </li>
				    </ul>

				  </div>
				</nav>
			</div>
        </header>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
				</div>
				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg');">
				</div>
				<div class="wrap" style="background-image:url('images/bc1.jpg');">
		    <div class="content">
		    <dl class="news clearfix">
				<section id='latest' style="background-image:url('images/bc1.jpg');">
					<form action="bb.php" method="post" accept-charset="utf-8" >
				<div class="row">
					<div class='col'>
					 <center>
					 <select onchange="javascript:location.href=this.value;"style="width: 300px; height:50px;">
					 <option>餐點</option>
					 <option value="drink.php">咖啡</option>
					 <option value="foodorder.php">主食</option>
					 <option value="otherfood.php">甜點</option>
					 </select>
				  </center>
					 </div>
			</div>
			</div>
		 		</div>

					<div class='col-md-12'>
				<div class="row" style="font-size:21px;background-image:url('images/bc1.jpg');">

				<div class='col-md-4 text-center'>
				<?php
				    $time = $_POST["time"];
				    echo "選擇時間是：".$time."<br>";
				?>
			</div>
			<div class='col-md-4 text-center'>
			  <?php
				    $weather = $_POST["weather"];
				    echo "選擇天氣是：".$weather."<br>";
       ?>
			 </div>
			 <div class='col-md-4 text-center'>
			 <?php
						$gen = $_POST["gen"];
				    echo "選擇性別是：".$gen."<br>";
				?>
			</div>

			<div class='col-md-12 text-center'>
			<center>
				<br>
				<?php
    $a1 = $_POST["a1"];
    $a2 = $_POST["a2"];
    $a3 = $_POST["a3"];

    $a4 = $_POST["a4"];
    $a5 = $_POST["a5"];
    $a6 = $_POST["a6"];

    $a7 = $_POST["a7"];
    $a8 = $_POST["a8"];
    $a9 = $_POST["a9"];

    $a10 = $_POST["a10"];
    $a11 = $_POST["a11"];
    $a12 = $_POST["a12"];


    echo "總金額是：".((int)$a1*100+(int)$a2*140+(int)$a3*150+(int)$a4*150+(int)$a5*150+(int)$a6*70+(int)$a7*85+(int)$a8*60+(int)$a9*65+(int)$a10*95+(int)$a11*95+(int)$a12*70)."<br>";

		$filename = "倉庫管理" . date("Y-m-d-H-i-s") . ".csv";

		header('Pragma: no-cache');

		header('Expires: 0');

		header('Content-Disposition: attachment;filename="' . $filename . '";');

		header('Content-Type: application/csv; charset=UTF-8');

		// 第一條

		$csv_arr[] = array("$a1","$a2","$a3");

		for ($j = 0; $j < count($csv_arr); $j++)

		{
		      if ($j == 0)
		      {
		      // 輸出 BOM 避免 Excel 讀取時會亂碼
		      echo "\xEF\xBB\xBF";
		      }
		        echo join(',', $csv_arr[$j]) . PHP_EOL;
		}

?>

<?php

$filename = "倉庫管理" . date("Y-m-d-H-i-s") . ".csv";

header('Pragma: no-cache');

header('Expires: 0');

header('Content-Disposition: attachment;filename="' . $filename . '";');

header('Content-Type: application/csv; charset=UTF-8');

// 第一條
$name = $_POST["fname"];
$age = $_POST["age"];
$sum = ((int)$a1*100+(int)$a2*140+(int)$a3*150+(int)$a4*150+(int)$a5*150+(int)$a6*70+(int)$a7*85+(int)$a8*60+(int)$a9*65+(int)$a10*95+(int)$a11*95+(int)$a12*70);

$csv_arr[] = array("$name","$age","$sum");

for ($j = 0; $j < count($csv_arr); $j++)

{
      if ($j == 0)
      {
      // 輸出 BOM 避免 Excel 讀取時會亂碼
      echo "\xEF\xBB\xBF";
      }
        echo join(',', $csv_arr[$j]) . PHP_EOL;
}
?>


					</center>
				</div>
			</div>
			</div>

	      </dl>
	      </div>
	    	</div>
			<center>
			<div style="font-size:25px;background-image:url('images/bc1.jpg');">

				<br>
			</div>
			<div style="border:0px;border-color:#000000;padding:74px;background-image:url('images/bc1.jpg');">
			</div>
			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
			</div>
		</center>
		</section>
	</dl>
</div>
</div>
				<?php else:?>
					<?php
					//沒有登入
					//使用php header 來轉址
					header('Location: menufront.php');
					?>
				<?php endif;?>
			</body>
			<footer>
				<div style="background-image:url('images/bc.jpg');">
				<br>
				<div class="container">
					<div class='row'>
					<div class='col-md-3 text-left'>
					</div>
					<div class='col-md-6 text-center'>
						<br>
						<br>
						<font color="#ffffff"><h5>𝒲𝒽𝑒𝓇𝑒 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒸💗𝒻𝒻𝑒𝑒, 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒶 𝓌𝒶𝓎.</h5></font>
					</div>
					<div class='col-md-3 text-left' style="font-size:15px">
						<center>
						<a class="navbar-brand" href="menuback.php"><img src='images/ig.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/fb.jpg' width='44'></a>
						<a class="navbar-brand" href="menuback.php"><img src='images/twitter.jpg' width='44'></a>
						<p><br><font color="#ffffff">403台中市西區公益路147號<br>
						Phone: (04)576-2276</font>
					  </p>
						</center>
					</div>
					</div>
				</div>
				<br>
			</div>
			</footer>
</html>
