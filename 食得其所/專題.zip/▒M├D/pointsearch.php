<?php

$link = mysqli_connect("localhost","root",
                       "ioioio330","test")
        or die("無法開啟MySQL資料庫連接!<br/>");


$name = $_POST["name"];
$ti = $_POST["ti"];
$gender = $_POST["gender"];
$weather = $_POST["weather"];



if($_POST["name"]!=null && $_POST["gender"]!=null && $_POST["ti"]!=null){//明子性別時間
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name' AND gender='$gender' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["weather"]!=null && $_POST["gender"]!=null && $_POST["ti"]!=null){//天氣性別時間
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather' AND gender='$gender' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["weather"]!=null && $_POST["gender"]!=null && $_POST["name"]!=null){//天氣性別民子
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather' AND gender='$gender' AND drink_name='$name'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["weather"]!=null && $_POST["name"]!=null && $_POST["ti"]!=null){//天氣明子時間
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather' AND drink_name='$name' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["name"]!=null && $_POST["ti"]!=null){//明子時間
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["name"]!=null && $_POST["weather"]!=null){//明子天氣
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name' AND weather='$weather'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["name"]!=null && $_POST["gender"]!=null){//明子性別
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name' AND gender='$gender'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["weather"]!=null && $_POST["ti"]!=null){//時間天氣
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["weather"]!=null && $_POST["gender"]!=null){//天氣性別
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather' AND gender='$gender'");
  mysqli_query($link, 'SET NAMES utf8');
}

elseif($_POST["ti"]!=null && $_POST["gender"]!=null){//時間性別
  $result = mysqli_query($link,"SELECT * FROM drink where ti='$ti' AND gender='$gender'");
  mysqli_query($link, 'SET NAMES utf8');
}
elseif($_POST["name"]!=null){//明子
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name'");
  mysqli_query($link, 'SET NAMES utf8');
}
elseif($_POST["weather"]!=null){//天氣
  $result = mysqli_query($link,"SELECT * FROM drink where weather='$weather'");
  mysqli_query($link, 'SET NAMES utf8');
}
elseif($_POST["ti"]!=null){//時間
  $result = mysqli_query($link,"SELECT * FROM drink where ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}
elseif($_POST["gender"]!=null){//性別
  $result = mysqli_query($link,"SELECT * FROM drink where gender='$gender'");
  mysqli_query($link, 'SET NAMES utf8');
}
elseif($_POST["name"]!=null && $_POST["gender"]!=null  && $_POST["weather"] && $_POST["ti"]){//全選
  $result = mysqli_query($link,"SELECT * FROM drink where drink_name='$name' AND gender='$gender' AND weather='$weather' AND ti='$ti'");
  mysqli_query($link, 'SET NAMES utf8');
}
else{
$result = mysqli_query($link,"SELECT * FROM drink ");
mysqli_query($link, 'SET NAMES utf8');
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>

<body>
<table width="700" border="1">
  <tr>
    <td>名稱</td>
    <td>杯數</td>
    <td>單價</td>
    <td>總價</td>
    <td>時間</td>
    <td>天氣</td>
    <td>性別</td>
  </tr>
  <?php
 for($i=1;$i<=mysqli_num_rows($result);$i++){
 $rs=mysqli_fetch_row($result);
  ?>
   <tr>
     <td><?php echo $rs[0]?></td>
     <td><?php echo $rs[1]?></td>
     <td><?php echo $rs[2]?></td>
     <td><?php echo $rs[3]?></td>
     <td><?php echo $rs[4]?></td>
     <td><?php echo $rs[5]?></td>
     <td><?php echo $rs[6]?></td>
   </tr>
   <?php
  }
  ?>
 </table>
 </body>
 </html>
