<?php

$link = mysqli_connect("localhost","jeff",
                       "ioioio330","test")
        or die("無法開啟MySQL資料庫連接!<br/>");


$state = $_POST["state"];
$sql = "DELETE FROM online WHERE state='$state'";
if(mysqli_query($link, $sql)){
} else{
}
?>
