<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="icon" href="images/goldlogonew.png" type="image/x-icon" />
<title>卡洛斯咖啡 - 點餐</title>
</head>
<body>
<?php
// 建立MySQL的資料庫連接
$link = @mysqli_connect(
            'localhost',  // MySQL主機名稱
            'root',       // 使用者名稱
            'ioioio330',  // 密碼
            'test');  // 預設使用的資料庫名稱
if ( !$link ) {
   exit();
}
else {

}
mysqli_close($link);  // 關閉資料庫連接
?>

</body>
</html>
