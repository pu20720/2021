<?php
// 載入db.php來連結資料庫

require_once 'test.php';
?>

<?php

$servername = "localhost";
$username = "root";
$password = "ioioio330";
$dbname = "test";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$db_num = "0";

$onlinetable = $_POST["onlinetable"];
$many = $_POST["many"];
$state = 0;


$sql = "INSERT INTO online (drink_name, cups, price,total,onlinetable,state)
VALUES ('紅心芭樂青蘋蛋糕', '$many', '120',120*$many,'$onlinetable','$state')";


if (mysqli_query($conn, $sql)) {
} else {
}

mysqli_close($conn);
 ?>
 <?php

 $servername = "localhost";
 $username = "root";
 $password = "ioioio330";
 $dbname = "test";
 // Create connection
 $conn = mysqli_connect($servername, $username, $password, $dbname);
 // Check connection
 if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
 }

 $db_num = "0";


 $onlinetable = $_POST["onlinetable"];
 $many = $_POST["many"];


 $sql = "INSERT INTO drinkless (drink_name, cups, price,total,onlinetable)
 VALUES ('紅心芭樂青蘋蛋糕', '$many', '120',120*$many,'$onlinetable')";


 if (mysqli_query($conn, $sql)) {
 } else {
 }

 mysqli_close($conn);
  ?>
  <!DOCTYPE html>
  <html>

  	<head>
  		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  		<link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC|Open+Sans&display=swap" rel="stylesheet">
  		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  		<script src="https://kit.fontawesome.com/68f8681dba.js" crossorigin="anonymous"></script>
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<link rel="icon" href="images/goldlogonew.png" type="image/x-icon" />
  		<title>卡洛斯咖啡 - 飲品</title>
      <script type="text/javascript" src="order.js"></script>
  	</head>
  		<style>
  		.buttona {
  			font-size:45px;
  		}
  		*,
  *:before,
  *:after {
      box-sizing: border-box;
  }

  img {
      max-width: 100%;
      height: auto;
  }

  .clearfix:after {
      content: '';
      display: table;
      clear: both;
  }

  body {
      line-height: 1.6;
  }

  .wrap {
      max-width:5000px;
      margin: 0 auto;
      padding: 1em;
  }

  h2 {
      font-size: 20px;
      font-weight: 600;
      padding-bottom: 1em;
  }

  .news li {
      float: left;
      width: 29.33333%;
      margin: 2%;
  }

  @media(max-width:768px) {
      .news li {
          width: 46%;/*50%記得扣除768px以上的左右margin共4%*/
      }
  }

  @media(max-width:569px) {
      .news li {
          width: 96%;/*100%記得扣除768px以上的左右margin共4%*/
      }
  }
  dl{
  	list-style-type:none;
  	margin:0px;
  }
  .text_box {
  width: 60px;
  height: 43px;
  text-align: center;
  border: 1px solid #7B7B7B;
  }
  .box {
  padding: 30px;
  }
  .one{
  font-size: 20px;
  }
  </style>
  <body>
  	<header>
  				<div style="background-image:url('images/bc.jpg');">
  				<nav class="navbar navbar-expand-lg navbar-light">
  				  <a class="navbar-brand" href=""><img src='images/goldlogonew.png' width='100'></a>
  				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  				    <span class="navbar-toggler-icon"></span>
  				  </button>

  					<div class="collapse navbar-collapse" id="navbarSupportedContent" style="font-size: 30px">
  				    <ul class="navbar-nav mr-auto">
  							<li class="nav-item">
  								<a class="nav-link" href="orderonline.php"><font color="#ffffff">線上點餐</font></a>
  							</li>
  				    </ul>

  				  </div>
  				</nav>
  			</div>
          </header>
  				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
  				</div>
  				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg');">
  				</div>
  				<div class="wrap" style="background-image:url('images/bc1.jpg');">
  		    <div class="content">
  		    <dl class="news clearfix">
  				<section id='latest' style="background-image:url('images/bc1.jpg');">
  					<form action="insert.php" method="post" accept-charset="utf-8" >
  					<div class="row">
  					<div class='col-md-3 text-center'>
  					 <select onchange="javascript:location.href=this.value;"style="width: 300px; height:50px;">
  					 <option>餐點</option>
  					 <option value="drinkonlinenew.php">飲品</option>
  					 <option value="eatonlinenew.php">主食</option>
  					 <option value="dessertonlinenew.php">甜點</option>
  					 </select>
  					 </div>

  			</div>
  			</div>
  		 		</div>

  				<div class="wrap" style="background-image:url('images/bc1.jpg');">
  						<div class="content" style="background-image:url('images/bc1.jpg');">
  								<dl class="news clearfix">
  									<li>
  										<a href="dessert01onlinenew.php">
  											<img src="images/ds1.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">栗子三重奏蛋糕</div>
  											<div style="font-size:29px">NT : 120</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert02onlinenew.php">
  											<img src="images/ds2.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">水果布蕾香緹蛋糕</div>
  											<div style="font-size:29px">NT : 140</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert03onlinenew.php">
  											<img src="images/ds3.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">紅心芭樂青蘋蛋糕</div>
  											<div style="font-size:29px">NT : 120</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert04onlinenew.php">
  											<img src="images/ds4.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">柚香伯爵塔</div>
  											<div style="font-size:29px">NT : 120</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert05onlinenew.php">
  											<img src="images/ds5.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">法式黑森林蛋糕</div>
  											<div style="font-size:29px">NT : 120</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert06onlinenew.php">
  											<img src="images/ds6.png" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">經典千層薄餅</div>
  											<div style="font-size:29px">NT : 120</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert07onlinenew.php">
  											<img src="images/ds7.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">可可伯爵薄餅</div>
  											<div style="font-size:29px">NT : 130</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert08onlinenew.php">
  											<img src="images/ds8.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">經典起司蛋糕</div>
  											<div style="font-size:29px">NT : 100</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert09onlinenew.php">
  											<img src="images/ds9.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">咖啡巧克力松露蛋糕</div>
  											<div style="font-size:29px">NT : 85</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert10onlinenew.php">
  											<img src="images/ds10.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">檸檬塔</div>
  											<div style="font-size:29px">NT : 80</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert11onlinenew.php">
  											<img src="images/ds11.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">法式千層薄餅</div>
  											<div style="font-size:29px">NT : 95</div>
  										</center>
  									</li>
  									<li>
  										<a href="dessert12onlinenew.php">
  											<img src="images/ds12.jpg" alt="">
  										</a>
  											<center>
  											<div style="font-size:29px">岩漿巧克力蛋糕</div>
  											<div style="font-size:29px">NT : 90</div>
  										</center>
  									</li>
  								</dl>
  						</div>
  				</div>

  	            </dl>
  	        </div>
  	    	</div>
  			<center>
  			<div style="font-size:35px;background-image:url('images/bc1.jpg');;">
  			</div>

  			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg');">
  			</div>
  			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
  			</div>
  		</center>
  		</section>
  	</dl>
  </div>
  </div>
  			</body>
  			<footer>
  				<div style="background-image:url('images/bc.jpg');">
  				<br>
  				<div class="container">
  					<div class='row'>
  					<div class='col-md-3 text-left'>
  					</div>
  					<div class='col-md-6 text-center'>
  						<br>
  						<br>
  						<font color="#ffffff"><h5>𝒲𝒽𝑒𝓇𝑒 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒸💗𝒻𝒻𝑒𝑒, 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒶 𝓌𝒶𝓎.</h5></font>
  					</div>
  					<div class='col-md-3 text-left' style="font-size:15px">
  						<center>
  						<a class="navbar-brand" href="menuback.php"><img src='images/ig.jpg' width='44'></a>
  						<a class="navbar-brand" href="menuback.php"><img src='images/fb.jpg' width='44'></a>
  						<a class="navbar-brand" href="menuback.php"><img src='images/twitter.jpg' width='44'></a>
  						<p><br><font color="#ffffff">403台中市西區公益路147號<br>
  						Phone: (04)576-2276</font>
  					  </p>
  						</center>
  					</div>
  					</div>
  				</div>
  				<br>
  			</div>
  			</footer>
  </html>
