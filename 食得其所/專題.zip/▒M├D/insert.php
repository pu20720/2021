<?php
// 載入db.php來連結資料庫

require_once 'test.php';
?>

<h3>sql插入結果</h3>
<?php

$servername = "localhost";
$username = "root";
$password = "ioioio330";
$dbname = "test";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$a1 = $_POST["a1"];
$a2 = $_POST["a2"];
$a3 = $_POST["a3"];

$a4 = $_POST["a4"];
$a5 = $_POST["a5"];
$a6 = $_POST["a6"];

$a7 = $_POST["a7"];
$a8 = $_POST["a8"];
$a9 = $_POST["a9"];

$a10 = $_POST["a10"];
$a11 = $_POST["a11"];
$a12 = $_POST["a12"];

$total = ((int)$a1*100+(int)$a2*140+(int)$a3*150+(int)$a4*150+(int)$a5*150+(int)$a6*70+(int)$a7*85+(int)$a8*60+(int)$a9*65+(int)$a10*95+(int)$a11*95+(int)$a12*70);
$sum[]=[];

$ti = $_POST["ti"];
$weather = $_POST["weather"];
$gender = $_POST["gen"];
$number=1;
//判斷是否為0

    if($a1>0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑系列冠軍特調美式', '$a1', '100',100*$a1,'$ti','$weather','$gender')";
    $number++;
  }

    if($a2>0){
      $sql = "INSERT  INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑系列冠軍特調拿鐵', '$a2', '140',140*$a2,'$ti','$weather','$gender')";
    $number++;
    }

    if($a3>0){
      $sql = "INSERT  INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑沃冠軍特調風味拿鐵-榛果', '$a3', '150',150*$a3,'$ti','$weather','$gender')";
    $number++;
    }
    if($a4>0){
      $sql = "INSERT  INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑沃冠軍特調風味拿鐵-玫瑰', '$a4', '150',150*$a4,'$ti','$weather','$gender')";
    $number++;
    }
    if($a5>0){
      $sql = "INSERT  INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑沃冠軍特調風味拿鐵-黑糖', '$a5', '150',150*$a5,'$ti','$weather','$gender')";
    $number++;
    }
    if($a6!=0){
      $sql = "INSERT  INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','卡布奇諾', '$a6', '70',70*$a6,'$ti','$weather','$gender')";
    $number++;
    }
    if($a7!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','檸檬咖啡', '$a7', '85',85*$a7,'$ti','$weather','$gender')";
    $number++;
    }
    if($a8!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','紅茶厚奶', '$a8', '60',60*$a8,'$ti','$weather','$gender')";
    $number++;
    }
    if($a9!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','黑糖厚奶', '$a9', '65',65*$a9,'$ti','$weather','$gender')";
    $number++;
    }
    if($a10!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','抹茶布蕾厚奶', '$a10', '95',95*a10,'$ti','$weather','$gender')";
    $number++;
    }
    if($a11!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','可可布蕾厚奶', '$a11', '95',95*$a11,'$ti','$weather','$gender')";
    $number++;
    }
    if($a12!=0){
      $sql = "INSERT INTO drink (number,drink_name, cups, price,total,ti,weather,gender)
    VALUES ('$number','手作金萱烏龍', '$a12', '70',70*$a12,'$ti','$weather','$gender')";
    $number++;
    }





if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
 ?>
