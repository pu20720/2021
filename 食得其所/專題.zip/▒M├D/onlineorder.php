<?php
// 載入db.php來連結資料庫

require_once 'test.php';
?>

<?php

$link = mysqli_connect("localhost","jeff",
                       "ioioio330","test")
        or die("無法開啟MySQL資料庫連接!<br/>");


  $result = mysqli_query($link,"SELECT * FROM online");
?>
<?php header('refresh: 20;url="onlineorder.php"') ?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>無標題文件</title>
  </head>

  <body>
  <table width="700" border="1">
  <?php
  for($i=1;$i<=mysqli_num_rows($result);$i++){
  $rs=mysqli_fetch_row($result);

   ?>
    <tr>
      <td><?php echo $rs[0]?></td>
      <td><?php echo $rs[1]?></td>
      <td><?php echo $rs[2]?></td>
      <td><?php echo $rs[3]?></td>
      <td><?php echo $rs[4]?></td>
      <td><form action="searchbackonline.php" method="post" class="font">



      桌號: <Select name="onlinetable"style="width: 100px; height:50px; text-align:center;">
      <Option Value"null"></Option>
      <Option Value"1">1</Option>
      <Option Value"2">2</Option>
      <Option Value"3">3</Option>
      <Option Value"4">4</Option>
      </Select></td>

       
  </tr>
  <?php
 }
 ?>
