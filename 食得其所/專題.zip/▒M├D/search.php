<?php
$link = mysqli_connect("localhost","root",
                       "ioioio330","test")
        or die("無法開啟MySQL資料庫連接!<br/>");


$result = mysqli_query($link, "SELECT * FROM foodnew");
mysqli_query($link, 'SET NAMES utf8');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>

<body>
<table width="700" border="1">
  <tr>
    <td>名稱</td>
    <td>性別</td>
    <td>數量</td>
    <td>天氣</td>
  </tr>
  <?php
 for($i=1;$i<=mysqli_num_rows($result);$i++){
 $rs=mysqli_fetch_row($result);
  ?>
   <tr>
     <td><?php echo $rs[0]?></td>
     <td><?php echo $rs[1]?></td>
     <td><?php echo $rs[2]?></td>
     <td><?php echo $rs[3]?></td>
   </tr>
   <?php
  }
  ?>
 </table>
 </body>
 </html>
