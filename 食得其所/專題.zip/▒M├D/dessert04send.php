<?php
// 載入db.php來連結資料庫

require_once 'test.php';
?>

<?php

$servername = "localhost";
$username = "root";
$password = "ioioio330";
$dbname = "test";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$ti = $_POST["ti"];
$weather = $_POST["weather"];
$gender = $_POST["gen"];
$many = $_POST["many"];


$sql = "INSERT INTO drink (drink_name, cups, price,total,ti,weather,gender)
VALUES ('柚香伯爵塔', '$many', '120',120*$many,'$ti','$weather','$gender')";



if (mysqli_query($conn, $sql)) {
} else {
}

mysqli_close($conn);
 ?>
 <?php
 	session_start(); //啟動 session
 ?>
 <!DOCTYPE html>
 <html>

 	<head>
 		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 		<link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC|Open+Sans&display=swap" rel="stylesheet">
 		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
 		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
 		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 		<script src="https://kit.fontawesome.com/68f8681dba.js" crossorigin="anonymous"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <link rel="icon" href="images/goldlogonew.png" type="image/x-icon" />
 		<title>卡洛斯咖啡 - 甜點</title>
     <script type="text/javascript" src="order.js"></script>
 	</head>
 		<style>
 		.buttona {
 			font-size:45px;
 		}
 		*,
 *:before,
 *:after {
     box-sizing: border-box;
 }

 img {
     max-width: 100%;
     height: auto;
 }

 .clearfix:after {
     content: '';
     display: table;
     clear: both;
 }

 body {
     line-height: 1.6;
 }

 .wrap {
     max-width:5000px;
     margin: 0 auto;
     padding: 1em;
 }

 h2 {
     font-size: 20px;
     font-weight: 600;
     padding-bottom: 1em;
 }

 .news li {
     float: left;
     width: 29.33333%;
     margin: 2%;
 }

 @media(max-width:768px) {
     .news li {
         width: 46%;/*50%記得扣除768px以上的左右margin共4%*/
     }
 }

 @media(max-width:569px) {
     .news li {
         width: 96%;/*100%記得扣除768px以上的左右margin共4%*/
     }
 }
 dl{
 	list-style-type:none;
 	margin:0px;
 }
 .text_box {
 width: 60px;
 height: 43px;
 text-align: center;
 border: 1px solid #7B7B7B;
 }
 .box {
 padding: 30px;
 }
 .one{
 font-size: 20px;
 }
 </style>
 <body>
 	<?php
 		//如果有 $_SESSION['is_login'] 這變數，以及 $_SESSION['is_login'] 為 true，就是已經登入了
 		if(isset($_SESSION['is_login']) && $_SESSION['is_login']):
 	?>
         <header>
 				<div style="background-image:url('images/bc.jpg');">
 				<nav class="navbar navbar-expand-lg navbar-light">
 				  <a class="navbar-brand" href="menuback.php"><img src='images/goldlogonew.png' width='100'></a>
 				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
 				    <span class="navbar-toggler-icon"></span>
 				  </button>

 					<div class="collapse navbar-collapse" id="navbarSupportedContent" style="font-size: 30px">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="menuback.php"><font color="#ffffff">首頁</font></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="order.php"><font color="#ffffff">點餐</font></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="checkoutnew.php"><font color="#ffffff">結帳</font></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="searchtotal.php"><font color="#ffffff">查詢</font></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php"><font color="#ffffff">登出</font></a>
              </li>
            </ul>


 				  </div>
 				</nav>
 			</div>
         </header>
 				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
 				</div>
 				<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg')">
 				</div>
 				<div class="wrap" style="background-image:url('images/bc1.jpg');">
 		    <div class="content">
 		    <dl class="news clearfix">
 				<section id='latest' style="background-image:url('images/bc1.jpg');">
 					<form action="bb.php" method="post" accept-charset="utf-8" >
 					<div class="row">
 					<div class='col-md-3 text-center'>
 					 <select onchange="javascript:location.href=this.value;"style="width: 300px; height:50px;">
 					 <option>餐點</option>
 					 <option value="drink.php">飲品</option>
 					 <option value="eat.php">主食</option>
 					 <option value="dessert.php">甜點</option>
 					 </select>
 					 </div>
 			</div>
 			</div>
 		 		</div>
 									<div class='col-md-12 text-center' style="background-image:url('images/bc1.jpg');">
 										<div class='row'>
 			                <table id="tab" align="center" data-toggle="table" >
 									  	  <div class='col-md-3 text-left'>
 			                   <td>
 													<div class='box'>
 														<div class='upper'>
 															<a href="dessert01.php">
 															<img src='images/s1.jpg' width='420'>
 														</a>
 												  	</div>
 														<div class='lower' style="text-align:center">
 													  	<div style="font-size:32px">栗子三重奏蛋糕</div>
 												  	</div>
 														<div style="text-align:center">
 			                          <span style="font-size:25px">NT:<span class="price">120
 			    									</div>
 									  	  </div>
 									    </div>
 											<div class='col-md-3 text-left'>
 			                 <td>
 												 <div class='box'>
 			 										<div class='upper'>
 														<a href="dessert02.php">
 			 											<img src='images/s2.jpg' width='420'>
 														</a>
 			 										</div>
 			 										<div class='lower' style="text-align:center">
 			 											<div style="font-size:32px">水果布蕾香緹蛋糕</div>
 			 										</div>
 			 										<div style="text-align:center">
 			 												<span style="font-size:25px">NT:<span class="price">140
 			 										</div>
 			 								</div>
 			               </div>

 			               <div class='col-md-3 text-left'>
 			                <td>
 												<div class='box'>
 			 									 <div class='upper'>
 													 <a href="dessert03.php">
 			 										 <img src='images/s3.jpg' width='420'>
 												 </a>
 			 									 </div>
 			 									 <div class='lower' style="text-align:center">
 			 										 <div style="font-size:32px">紅心芭樂青蘋蛋糕</div>
 			 									 </div>
 			 									 <div style="text-align:center">
 			 											 <span style="font-size:25px">NT:<span class="price">120
 			 									 </div>
 			 							 </div>
 			              </div>
 			              </table>
 			            </div>
 			          </div>

 								<div class='col-md-12 text-center' style="background-image:url('images/bc1.jpg');">
 									<div class='row'>
 			              <table id="tab" align="center">
 											<div class='col-md-3 text-left'>
 			                 <td>
 			 									<div class='box'>
 			  									 <div class='upper'>
 														 <a href="dessert04.php">
 			  										 <img src='images/s4.jpg' width='420'>
 													 	</a>
 			  									 </div>
 			  									 <div class='lower' style="text-align:center">
 			  										 <div style="font-size:32px">柚香伯爵塔</div>
 			  									 </div>
 			  									 <div style="text-align:center">
 			  											 <span style="font-size:25px">NT:<span class="price">120
 			  									 </div>
 			  							 </div>
 			               </div>

 										 <div class='col-md-3 text-left'>
 			 							 <td>
 			 								 <div class='box'>
 			 									<div class='upper'>
 													<a href="dessert05.php">
 			 										<img src='images/s5.jpg' width='420'>
 													</a>
 			 									</div>
 			 									<div class='lower' style="text-align:center">
 			 										<div style="font-size:32px">法式黑森林蛋糕</div>
 			 									</div>
 			 									<div style="text-align:center">
 			 											<span style="font-size:25px">NT:<span class="price">120
 			 									</div>
 			 							</div>
 			 						 </div>
 									 <div class='col-md-3 text-left'>
 										<td>
 											<div class='box'>
 											 <div class='upper'>
 												 <a href="dessert06.php">
 												 <img src='images/s6.png' width='420'>
 											 </a>
 											 </div>
 											 <div class='lower' style="text-align:center">
 												 <div style="font-size:32px">經典千層薄餅</div>
 											 </div>
 											 <div style="text-align:center">
 													 <span style="font-size:25px">NT:<span class="price">120
 											 </div>
 									 </div>
 									</div>
 			            </table>
 			          </div>
 			        </div>

 							<div class='col-md-12 text-center' style="background-image:url('images/bc1.jpg');">
 								<div class='row'>
 									<table id="tab" align="center" data-toggle="table" >
 										<div class='col-md-3 text-left'>
 										 <td>
 											 <div class='box'>
 												<div class='upper'>
 													<img src='images/s7.jpg' width='420'>
 												</div>
 												<div class='lower' style="text-align:center">
 													<div style="font-size:32px">可可伯爵薄餅</div>
 												</div>
 												<div style="text-align:center">
 														<span style="font-size:25px">NT:<span class="price">130
 												</div>
 										</div>
 									 </div>

 									 <div class='col-md-3 text-left'>
 			 						 <td>
 			 							 <div class='box'>
 			 								<div class='upper'>
 			 									<img src='images/s8.jpg' width='420'>
 			 								</div>
 			 								<div class='lower' style="text-align:center">
 			 									<div style="font-size:32px">經典起司蛋糕</div>
 			 								</div>
 			 								<div style="text-align:center">
 			 										<span style="font-size:25px">NT:<span class="price">100
 			 								</div>
 			 						</div>
 			 					 </div>

 								 <div class='col-md-3 text-left'>
 									<td>
 										<div class='box'>
 										 <div class='upper'>
 											 <img src='images/s9.jpg' width='420'>
 										 </div>
 										 <div class='lower' style="text-align:center">
 											 <div style="font-size:32px">咖啡巧克力松露蛋糕</div>
 										 </div>
 										 <div style="text-align:center">
 												 <span style="font-size:25px">NT:<span class="price">85
 										 </div>
 								 </div>
 								</div>
 								</table>
 							</div>
 					</div>

 					<div class='col-md-12 text-center' style="background-image:url('images/bc1.jpg');">
 						<div class='row'>
 							<table id="tab" align="center" data-toggle="table" >
 								<div class='col-md-3 text-left'>
 								 <td>
 									 <div class='box'>
 										<div class='upper'>
 											<img src='images/s10.jpg' width='420'>
 										</div>
 										<div class='lower' style="text-align:center">
 											<div style="font-size:32px">檸檬塔</div>
 										</div>
 										<div style="text-align:center">
 												<span style="font-size:25px">NT:<span class="price">80
 										</div>
 								</div>
 							 </div>

 							 <div class='col-md-3 text-left'>
 		 					 <td>
 		 						 <div class='box'>
 		 							<div class='upper'>
 		 								<img src='images/s11.jpg' width='420'>
 		 							</div>
 		 							<div class='lower' style="text-align:center">
 		 								<div style="font-size:32px">法式千層薄餅</div>
 		 							</div>
 		 							<div style="text-align:center">
 		 									<span style="font-size:25px">NT:<span class="price">95
 		 							</div>
 		 					</div>
 		 				 </div>

 						 <div class='col-md-3 text-left'>
 							<td>
 								<div class='box'>
 								 <div class='upper'>
 									 <img src='images/s12.jpg' width='420'>
 								 </div>
 								 <div class='lower' style="text-align:center">
 									 <div style="font-size:32px">岩漿巧克力蛋糕</div>
 								 </div>
 								 <div style="text-align:center">
 										 <span style="font-size:25px">NT:<span class="price">90
 								 </div>
 						 </div>
 						</div>
 						</table>
 					</div>
 			</div>
 	            </dl>
 	        </div>
 	    	</div>
 			<center>

 			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/bc1.jpg');">
 			</div>
 			<div style="border:0px;border-color:#000000;padding:5px;background-image:url('images/gold.jpg')">
 			</div>
 		</center>
 		</section>
 	</dl>
 </div>
 </div>
 				<?php else:?>
 					<?php
 					//沒有登入
 					//使用php header 來轉址
 					header('Location: menufront.php');
 					?>
 				<?php endif;?>
 			</body>
 			<footer>
 				<div style="background-image:url('images/bc.jpg');">
 				<br>
 				<div class="container">
 					<div class='row'>
 					<div class='col-md-3 text-left'>
 					</div>
 					<div class='col-md-6 text-center'>
 						<br>
 						<br>
 						<font color="#ffffff"><h5>𝒲𝒽𝑒𝓇𝑒 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒸💗𝒻𝒻𝑒𝑒, 𝓉𝒽𝑒𝓇𝑒 𝒾𝓈 𝒶 𝓌𝒶𝓎.</h5></font>
 					</div>
 					<div class='col-md-3 text-left' style="font-size:15px">
 						<center>
 						<a class="navbar-brand" href="menuback.php"><img src='images/ig.jpg' width='44'></a>
 						<a class="navbar-brand" href="menuback.php"><img src='images/fb.jpg' width='44'></a>
 						<a class="navbar-brand" href="menuback.php"><img src='images/twitter.jpg' width='44'></a>
 						<p><br><font color="#ffffff">403台中市西區公益路147號<br>
 						Phone: (04)576-2276</font>
 					  </p>
 						</center>
 					</div>
 					</div>
 				</div>
 				<br>
 			</div>
 			</footer>
 </html>
