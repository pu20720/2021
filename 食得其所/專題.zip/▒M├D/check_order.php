<?php
	//啟動session
	session_start();

	//假設的有效會員帳號
	$table = "0";


	//使用 isset 判別有沒有此變數可以使用
	if(isset($_POST['onlinetable']))
	{
		//直接對傳過來的帳號密碼做比對

		if($_POST['onlinetable'] != $table)
		{
			//如果密碼一樣，以及帳號一樣，那就代表正確，所以顯示登入成功
			$_SESSION['is_order'] = TRUE;
			//使用php header 來轉址 前往後台
			header('Location: drinkonline.php');
		}
		else
		{
			//要不然就是登入失敗
			$_SESSION['is_order'] = FALSE;
			$url = "drink01online.php";

			echo "<script>alert('新增訂單')</script>";
			echo "<script>window.location.href = '$url'</script>";
			//在session存一個 msg 變數


			//使用php header 來轉址 返回登入頁

		}
	}
	else
	{
		//使用php header 來轉址 返回登入頁
		header('Location: check_order.php');
	}
?>
