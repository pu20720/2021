<?php


$table = $_POST["table"];
$many = $_POST["many"];

echo "桌號 ". $table;
echo "數量 ". $many;


?>
