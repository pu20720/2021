<html>
<head>
<meta charset="utf-8">
<title>菜鸟教程(runoob.com)</title>
</head>
<body>

<form action="pointsearch.php" method="post">
名稱: <Select name="name">
<Option Value"null"></Option>
<Option Value"1">黑系列 冠軍特調美式</Option>
<Option Value"2">黑系列 冠軍特調拿鐵</Option>
<Option Value"3">黑沃冠軍特調風味拿鐵-榛果</Option>
<Option Value"4">黑沃冠軍特調風味拿鐵-玫瑰</Option>
<Option Value"5">黑沃冠軍特調風味拿鐵-黑糖</Option>
<Option Value"6">卡布奇諾</Option>
<Option Value"7">檸檬咖啡</Option>
<Option Value"8">紅茶厚奶</Option>
<Option Value"9">黑糖厚奶</Option>
</Select>

時間: <Select name="ti">
<Option Value"null"></Option>
<Option Value"break">早上</Option>
<Option Value"lunch">中午</Option>
<Option Value"after">下午</Option>
<Option Value"noon">晚上</Option>
</Select>

性別: <Select name="gender">
<Option Value"null"></Option>
<Option Value"man">男生</Option>
<Option Value"girl">女生</Option>
</Select>

天氣: <Select name="weather">
<Option Value"null"></Option>
<Option Value"sun">晴天</Option>
<Option Value"rain">雨天</Option>
<Option Value"cloud">陰天</Option>
</Select>

<input type="submit" value="提交">
</form>

</body>
</html>
