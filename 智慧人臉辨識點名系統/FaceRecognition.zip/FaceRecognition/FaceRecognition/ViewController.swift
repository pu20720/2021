//  ViewController.swift
//  FaceRecognition
//
//  Created by Yung-Yu Chen on 2021/5/23.
//  Copyright © 2021 PU. All rights reserved.
import UIKit

class ViewController : UIViewController {
    
    @IBOutlet var teacherName: [UIButton]!
    @IBOutlet weak var finalName: UIButton!
    var name : String = ""  //要帶入下個頁面的字串
    
    @IBOutlet var subjectsName: [UIButton]!
    @IBOutlet weak var finalSubject: UIButton!
    var subject : String = ""  //要帶入下個頁面的科目名
    
    @IBAction func startName(_ sender: UIButton) {
        for names in teacherName{
            names.isHidden = !names.isHidden
        }
    }
    
    @IBAction func clickName(_ sender: UIButton) {
        for names in teacherName{
            names.isHidden = true
        }
        name = sender.currentTitle ?? ""  //存入字串name
        finalName.setTitle(name, for: .normal)
        finalName.backgroundColor = UIColor.black
    }
    
    @IBAction func startSubject(_ sender: UIButton) {
        for subjects in subjectsName{
            subjects.isHidden = !subjects.isHidden
        }
    }
    
    @IBAction func clickSubject(_ sender: UIButton) {
        for subjects in subjectsName{
            subjects.isHidden = true
        }
        subject = sender.currentTitle ?? "" //存入字串subject
        finalSubject.setTitle(subject, for: .normal)
        finalSubject.backgroundColor = UIColor.black
    }
    
    @IBOutlet weak var startRollCall: UIButton!  //開始點名按鈕
    @IBOutlet weak var showClick: UILabel!
    @IBOutlet weak var finalTime: UILabel!  //顯示在畫面上的時間Lable
    
    @IBAction func getTime(_ sender: UIButton) {
        let nowTime : DateFormatter = DateFormatter()
        nowTime.dateFormat = "yyyy/MM/dd   HH:mm:ss"
        nowTime.locale = Locale(identifier: "zh_Hant_TW")  //設定地區
        nowTime.timeZone = TimeZone(identifier: "Asia/Taipei") //設定時區
        let nowTimeString: String = nowTime.string(from: Date())
        
        //設定顯示條件
        if finalName.backgroundColor == UIColor.black && finalSubject.backgroundColor == UIColor.black{
            finalTime.text = nowTimeString  //顯示時間出來
            finalTime.backgroundColor = UIColor.green
            
            startRollCall.isHidden = false
            showClick.isHidden = false
        }
    }
    
    //開機執行
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //載入背景Logo
        let background = UIImageView(frame: UIScreen.main.bounds)
        background.image = UIImage(named: "logo.png")
        background.contentMode = .scaleAspectFit
        self.view.insertSubview(background, at:0 )
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondViewData = segue.destination as? SecondViewController
        secondViewData?.teacherName = name
        secondViewData?.subjectName = subject
        secondViewData?.rollcallTime = finalTime.text
    }
}
