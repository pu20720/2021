//
//  SecondViewController.swift
//  FaceRecognition
//
//  Created by Yung-Yu Chen on 2021/5/31.
//  Copyright © 2021 PU. All rights reserved.
//
import UIKit
class SecondViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    //接收的字串
    var teacherName: String?
    var subjectName: String?
    var rollcallTime: String?

    @IBOutlet weak var buttonImage: UIButton!
    @IBOutlet weak var haveAttendedSrudents1: UILabel!
    @IBOutlet weak var haveAttendedSrudents2: UILabel!
    @IBOutlet weak var haveAttendedSrudents3: UILabel!
    @IBOutlet weak var haveAttendedSrudents4: UILabel!
    @IBOutlet weak var haveAttendedStudents5: UILabel!
    @IBOutlet weak var haveAttendedStudents6: UILabel!
    @IBOutlet weak var haveAttendedStudents7: UILabel!
    @IBOutlet weak var haveAttendedStudents8: UILabel!
    @IBOutlet weak var haveAttendedStudents9: UILabel!
    @IBOutlet weak var haveAttendedStudents10: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //從相簿選擇照片
    func photopicker(){
        let photoController = UIImagePickerController()
        photoController.delegate = self
        photoController.sourceType = .photoLibrary
        present(photoController, animated: true, completion: nil)
    }
    //相機選擇
    func camera(){
        let cameraController = UIImagePickerController()
        cameraController.delegate = self
        cameraController.sourceType = .camera
        present(cameraController, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as? UIImage
        buttonImage.setImage(image, for: .normal)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func imageButton(_ sender: UIButton) {
        let controller = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        //相機拍照
        let cameraAction = UIAlertAction(title: "開啟相機拍照", style: .default){
            (_) in self.camera()
        }
        //選擇相簿
        let libraryAction = UIAlertAction(title: "從相簿中選擇", style: .default){
            (_) in self.photopicker()
        }
        //刪除
        let deleteAction = UIAlertAction(title: "刪除", style: .destructive){
            (_) in sender.setImage(UIImage(named: "chooseStudent_logo.png"), for: .normal)
        }
        //取消
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        
        controller.addAction(cameraAction)
        controller.addAction(libraryAction)
        controller.addAction(deleteAction)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)
    }
    
    
    //按下按鈕發送ＡＰＩ給伺服器
    @IBAction func sendApiToServer(_ sender: UIButton) {
        // 按鈕圖片 -> 二進位
        //let ImageData = buttonImage.currentImage!.pngData()!
        // 壓縮圖片 ７０％
        let ImageData = buttonImage.currentImage?.jpegData(compressionQuality: 1.0)
        
        
        class AzureFaceRecognition: NSObject {
                    
            static let shared = AzureFaceRecognition()
            let APIKey = "bdb739c2779144c6bc25596ab6e92723"
            let FindSimilarsUrl = "https://westus.api.cognitive.microsoft.com/face/v1.0/findsimilars"
            let DetectUrl = "https://westus.api.cognitive.microsoft.com/face/v1.0/detect"
                    
            // See Face - Detect endpoint details
            func syncDetectFaceIds(imageData: Data) -> [String] {
                var headers: [String: String] = [:]
                headers["Content-Type"] = "application/octet-stream"
                headers["Ocp-Apim-Subscription-Key"] = APIKey
                let response = self.makePOSTRequest(url: DetectUrl, postData: imageData, headers: headers)
                let faceIds = extractFaceIds(fromResponse: response)
                        
                return faceIds
            }
                    
            // See Face - Find Similar endpoint details
            //https://westus.dev.cognitive.microsoft.com/docs/services/563879b61984550e40cbbe8d/operations/563879b61984550f30395237
            func findSimilars(faceId: String, faceIds: [String], completion: @escaping ([String]) -> Void) {
                var headers: [String: String] = [:]
                headers["Content-Type"] = "application/json"
                headers["Ocp-Apim-Subscription-Key"] = APIKey
                        
                let params: [String: Any] = [
                    "faceId": faceId,
                    "faceIds": faceIds,
                    "mode": "matchFace"
                ]
                        
                // Convert the Dictionary to Data
                let data = try! JSONSerialization.data(withJSONObject: params)
                        
                DispatchQueue.global(qos: .background).async {
                    let response = self.makePOSTRequest(url: self.FindSimilarsUrl, postData: data, headers: headers)
                    // Use a low confidence value to get more matches
                    let faceIds = self.extractFaceIds(fromResponse: response, minConfidence: 0.65)
                            
                    DispatchQueue.main.async {
                        completion(faceIds)
                    }
                }
            }
                    
            func extractFaceIds(fromResponse response: [AnyObject], minConfidence: Float? = nil) -> [String] {
                var faceIds: [String] = []
                for faceInfo in response {
                    if let faceId = faceInfo["faceId"] as? String  {
                        var canAddFace = true
                        if minConfidence != nil {
                            let confidence = (faceInfo["confidence"] as! NSNumber).floatValue
                            canAddFace = confidence >= minConfidence!
                        }
                        if canAddFace { faceIds.append(faceId) }
                    }
                            
                }
                return faceIds
            }
                    
            // Just a function that makes a POST request.
            func makePOSTRequest(url: String, postData: Data, headers: [String: String] = [:]) -> [AnyObject] {
                var object: [AnyObject] = []
                var request = URLRequest(url: URL(string: url)!)
                request.httpMethod = "POST"
                request.httpBody = postData
                        
                for header in headers {
                    request.addValue(header.value, forHTTPHeaderField: header.key)
                }
                        
                // Using semaphore to make request synchronous
                let semaphore = DispatchSemaphore(value: 0)
                        
                let task = URLSession.shared.dataTask(with: request) { data, response, error in
                    if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [AnyObject], json != nil {
                                object = json
                    }else {
                            print("ERROR response: \(String(data: data!, encoding: .utf8) ?? "")")
                    }
                    semaphore.signal()
                }
                        
                task.resume()
                _ = semaphore.wait(timeout: DispatchTime.distantFuture)
                        
                return object
            }
        }
                
        // 資料庫
        class students_Data{
            var student_FaceIds = ["86f7a063-a016-49bc-bd8d-f2fc1d58c171", "fc6b13ec-b02e-45d4-841a-9b32aebac7fb", "5951fd1d-fbf0-4c5c-b3ad-47fcc8a76fef", "3ab99a36-f90e-4db0-a6bf-34f454d9eb4e"]
            var student_name = ["陳咏裕", "何松益", "顏銘鋒", "林佳杰"]
            var student_class = ["資工四Ａ", "資工四Ａ", "資工四Ａ", "資工四Ａ"]
            var student_studentID = ["410727739", "410715732", "410715910", "410715685"]
            var waiting_for_roll_call : [String] = []  // 等待點名的學生
        }
                
        let azureFaceRecognition = AzureFaceRecognition()
        let student_data = students_Data()
                
        student_data.waiting_for_roll_call = azureFaceRecognition.syncDetectFaceIds(imageData: ImageData!)
        print(student_data.waiting_for_roll_call)
        var count = 1  // 目前正在進行點名的號碼  從第１位 至 最後１位
        
        
        // 把偵測到的學生名字秀出來
        func show_studentsName(receive_from_server:[String]) -> Void{
            //print(receive_from_server[0])
            if receive_from_server.count != 0{
                
            if count == 1{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedSrudents1.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 2{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedSrudents2.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 3{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedSrudents3.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 4{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedSrudents4.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 5{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents5.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 6{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents6.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 7{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents7.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 8{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents8.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 9{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents9.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }else if count == 10{
                for i in 0...student_data.student_FaceIds.count-1{
                    if receive_from_server[0] == student_data.student_FaceIds[i]{
                        haveAttendedStudents10.text = student_data.student_name[i] + "   已到 ！"
                        print(count)
                        break
                    }
                }
            }
                count += 1
            }else if count == 1 && receive_from_server.count == 0 && student_data.waiting_for_roll_call.count == 1{
                haveAttendedSrudents1.text = "  不明生物  ！"
            }
        }
        
        if student_data.waiting_for_roll_call.count != 0{
        // 用迴圈執行待點名陣列中所有 faceId
        for i in 0...student_data.waiting_for_roll_call.count-1{
            if i == 10 {
                break
            }
            // 先初始化出現的字串名
            if i == 0 {
                haveAttendedSrudents1.text = ""
                haveAttendedSrudents2.text = ""
                haveAttendedSrudents3.text = ""
                haveAttendedSrudents4.text = ""
                haveAttendedStudents5.text = ""
                haveAttendedStudents6.text = ""
                haveAttendedStudents7.text = ""
                haveAttendedStudents8.text = ""
                haveAttendedStudents9.text = ""
                haveAttendedStudents10.text = ""
            }
            azureFaceRecognition.findSimilars(faceId: student_data.waiting_for_roll_call[i], faceIds:student_data.student_FaceIds, completion: show_studentsName(receive_from_server:))
        }
        }else{
            haveAttendedSrudents1.text = "點名失敗！"
            haveAttendedSrudents2.text = ""
            haveAttendedSrudents3.text = ""
            haveAttendedSrudents4.text = ""
            haveAttendedStudents5.text = ""
            haveAttendedStudents6.text = ""
            haveAttendedStudents7.text = ""
            haveAttendedStudents8.text = ""
            haveAttendedStudents9.text = ""
            haveAttendedStudents10.text = ""
        }
    }
}
