# -*- coding: utf-8 -*-
# +
import multiprocessing
import cv2
import os
import coloredlogs, logging
from matplotlib import pyplot as plt
from example_darknet_adapter import Detect
from pathlib import Path
from resnet_eye import eye_classify
from resnet_nose import nose_classify
from resnet_mouth import mouth_classify
import numpy as np
from time import time
import numpy as np
import keras.backend as K
from keras.engine.topology import Layer, InputSpec
from keras.layers import Dense, Input
from keras.models import Model, Sequential, model_from_json
from keras.optimizers import SGD
from keras import callbacks
from keras.initializers import VarianceScaling
from sklearn.cluster import KMeans
from keras.preprocessing.image import ImageDataGenerator
from random import sample
import random
import csv
from PIL import Image

class ClusteringLayer(Layer):
    """
    Clustering layer converts input sample (feature) to soft label, i.e. a vector that represents the probability of the
    sample belonging to each cluster. The probability is calculated with student's t-distribution.

    # Example
    ```
        model.add(ClusteringLayer(n_clusters=10))
    ```
    # Arguments
        n_clusters: number of clusters.
        weights: list of Numpy array with shape `(n_clusters, n_features)` witch represents the initial cluster centers.
        alpha: degrees of freedom parameter in Student's t-distribution. Default to 1.0.
    # Input shape
        2D tensor with shape: `(n_samples, n_features)`.
    # Output shape
        2D tensor with shape: `(n_samples, n_clusters)`.
    """

    def __init__(self, n_clusters, weights=None, alpha=1.0, **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(ClusteringLayer, self).__init__(**kwargs)
        self.n_clusters = n_clusters
        self.alpha = alpha
        self.initial_weights = weights
        self.input_spec = InputSpec(ndim=2)

    def build(self, input_shape):
        assert len(input_shape) == 2
        input_dim = input_shape[1]
        self.input_spec = InputSpec(dtype=K.floatx(), shape=(None, input_dim))
        self.clusters = self.add_weight(shape = (self.n_clusters, input_dim), initializer='glorot_uniform', name='clusters')
        if self.initial_weights is not None:
            self.set_weights(self.initial_weights)
            del self.initial_weights
        self.built = True

    def call(self, inputs, **kwargs):
        """ student t-distribution, as same as used in t-SNE algorithm.
         Measure the similarity between embedded point z_i and centroid µ_j.
                 q_ij = 1/(1+dist(x_i, µ_j)^2), then normalize it.
                 q_ij can be interpreted as the probability of assigning sample i to cluster j.
                 (i.e., a soft assignment)
        Arguments:
            inputs: the variable containing data, shape=(n_samples, n_features)
        Return:
            q: student's t-distribution, or soft labels for each sample. shape=(n_samples, n_clusters)
        """
        q = 1.0 / (1.0 + (K.sum(K.square(K.expand_dims(inputs, axis=1) - self.clusters), axis=2) / self.alpha))
        q **= (self.alpha + 1.0) / 2.0
        q = K.transpose(K.transpose(q) / K.sum(q, axis=1)) # Make sure each sample's 10 values add up to 1.
        return q

    def compute_output_shape(self, input_shape):
        assert input_shape and len(input_shape) == 2
        return input_shape[0], self.n_clusters

    def get_config(self):
        config = {'n_clusters': self.n_clusters}
        base_config = super(ClusteringLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


logger = logging.getLogger(__name__)
coloredlogs.install(level='INFO', logger=logger)

def convert_bgr_to_rgb(bgr_image):
    return bgr_image[:,:,::-1]


def show_image_inline(cv2_img):
    %matplotlib inline
    
    plt_img = convert_bgr_to_rgb(cv2_img)
    plt.imshow(plt_img)
    plt.show()

    
def crop_image(cv2_img, x, y, w, h):
    # 這個 function 的職責為切割圖片。
    # 座標原先是在中點 改成最小 x和 y
    x -= w / 2
    y -= h / 2
    return cv2_img[int(y):int(y+h), int(x):int(x+w)]


def create_dir_if_not_exist(path):
    if not Path(path).is_dir():
        print("creating directory: " + path)
        os.makedirs(path)
    else:
        print("found directory: " + path)
        
        
# def predict_and_find_classify(darknet, origin_image):
#     detections = darknet.predict_image(origin_image)
#     classification = None
#     for detection in detections:
#         label, conf, position = detection
#         x, y, w, h = position
#         cropped_image = crop_image(origin_image, x, y, w, h)
#         if label == 'nose':
#             classification = mouth_classify(cropped_image)
#         elif label == 'face':
#             face_image = cropped_image
#     return classification,face_image

def predict_and_classification_voting(darknet, origin_image):
    detections = darknet.predict_image(origin_image)
    classification = None
    counter_A = 0
    counter_B = 0
    counter_C = 0
    counter_D = 0
    for detection in detections:
        label, conf, position = detection
        x, y, w, h = position
        cropped_image = crop_image(origin_image, x, y, w, h)

        if label == 'face':
            face_image = cropped_image
        if label == 'eye':
            classification = eye_classify(cropped_image)
            if classification == 'A':
                counter_A +=1
            elif classification == 'B':
                counter_B +=1
            elif classification == 'C':
                counter_C +=1
            else:
                counter_D +=1
                
        if label == 'nose':
            classification = nose_classify(cropped_image)
            if classification == 'A':
                counter_A +=1
            elif classification == 'B':
                counter_B +=1
            elif classification == 'C':
                counter_C +=1
            else:
                counter_D +=1
           
        if label == 'mouth':
            classification = mouth_classify(cropped_image)
            if classification == 'A':
                counter_A +=1
            elif classification == 'B':
                counter_B +=1
            elif classification == 'C':
                counter_C +=1
            else:
                counter_D +=1
                
#     if counter_B > counter_A and counter_B > counter_C and counter_B > counter_D:
#         print('hi')
#     else:
#         print('sup')
            
    
    if counter_A > counter_B and counter_A > counter_C and counter_A > counter_D:
        classification == 'A'
    elif counter_B > counter_A and counter_B > counter_C and counter_B > counter_D:
        classification == 'B'
    elif counter_C > counter_A and counter_C > counter_B and counter_C > counter_D:
        classification == 'C'
    else:
        classification == 'D'        

            
    print(counter_A,counter_B,counter_C,counter_D)
    
    return classification,face_image

def auto_A_model():
    with open("../result/cluster_weight/A_weights.config", "r") as text_file:
            json_string = text_file.read()
            model = Sequential()
            model = model_from_json(json_string, custom_objects={'ClusteringLayer': ClusteringLayer})
            model.load_weights("../result/cluster_weight/A_weights.weight", by_name=False)
    return model

def auto_B_model():
    with open("../result/cluster_weight/B_weights.config", "r") as text_file:
            json_string = text_file.read()
            model = Sequential()
            model = model_from_json(json_string, custom_objects={'ClusteringLayer': ClusteringLayer})
            model.load_weights("../result/cluster_weight/B_weights.weight", by_name=False)
    return model

def auto_C_model():
    with open("../result/cluster_weight/C_weights.config", "r") as text_file:
            json_string = text_file.read()
            model = Sequential()
            model = model_from_json(json_string, custom_objects={'ClusteringLayer': ClusteringLayer})
            model.load_weights("../result/cluster_weight/C_weights.weight", by_name=False)
    return model

def auto_D_model():
    with open("../result/cluster_weight/D_weights.config", "r") as text_file:
            json_string = text_file.read()
            model = Sequential()
            model = model_from_json(json_string, custom_objects={'ClusteringLayer': ClusteringLayer})
            model.load_weights("../result/cluster_weight/D_weights.weight", by_name=False)
    return model

def a0():
    with open("../csv_json_coco/filename/A0.csv") as file_name:
        rows = csv.DictReader(file_name)
        a0=[]
        for row in rows:
            a=row['name']
            a0.append(a)
        
        print(sample(a0, 5))
def a1():
    with open("../csv_json_coco/filename/A1.csv") as file_name:
        rows = csv.DictReader(file_name)
        a1=[]
        for row in rows:
            a=row['name']
            a1.append(a)
        
        print(sample(a1, 5))
def a2():
    with open("../csv_json_coco/filename/A2.csv") as file_name:
        rows = csv.DictReader(file_name)
        a2=[]
        for row in rows:
            a=row['name']
            a2.append(a)
        
        print(sample(a2, 5))
def a3():
    with open("../csv_json_coco/filename/A3.csv") as file_name:
        rows = csv.DictReader(file_name)
        a3=[]
        for row in rows:
            a=row['name']
            a3.append(a)
        
        print(sample(a3, 5))
def b0():
    with open("../csv_json_coco/filename/B0.csv") as file_name:
        rows = csv.DictReader(file_name)
        b0=[]
        for row in rows:
            a=row['name']
            b0.append(a)
        
        print(sample(b0, 5))
def b1():
    with open("../csv_json_coco/filename/B1.csv") as file_name:
        rows = csv.DictReader(file_name)
        b1=[]
        for row in rows:
            a=row['name']
            b1.append(a)
        
        print(sample(b1, 5))
def b2():
    with open("../csv_json_coco/filename/B2.csv") as file_name:
        rows = csv.DictReader(file_name)
        b2=[]
        for row in rows:
            a=row['name']
            b2.append(a)
        
        print(sample(b2, 5))
def b3():
    with open("../csv_json_coco/filename/B3.csv") as file_name:
        rows = csv.DictReader(file_name)
        b3=[]
        for row in rows:
            a=row['name']
            b3.append(a)
        
        print(sample(b3, 5))
def c0():
    with open("../csv_json_coco/filename/C0.csv") as file_name:
        rows = csv.DictReader(file_name)
        c0=[]
        for row in rows:
            a=row['name']
            c0.append(a)
        
        print(sample(c0, 5))
        
def c1():
    with open("../csv_json_coco/filename/C1.csv") as file_name:
        rows = csv.DictReader(file_name)
        c1=[]
        for row in rows:
            a=row['name']
            c1.append(a)
        
        print(sample(c1, 5))
        
def c2():
    with open("../csv_json_coco/filename/C2.csv") as file_name:
        rows = csv.DictReader(file_name)
        c2=[]
        for row in rows:
            a=row['name']
            c2.append(a)
        
        print(sample(c2, 5))

def c3():
    with open("../csv_json_coco/filename/C3.csv") as file_name:
        rows = csv.DictReader(file_name)
        c3=[]
        for row in rows:
            a=row['name']
            c3.append(a)
        
        print(sample(c3, 5))
        
def d0():
    with open("../csv_json_coco/filename/D0.csv") as file_name:
        rows = csv.DictReader(file_name)
        d0=[]
        for row in rows:
            a=row['name']
            d0.append(a)
        
        print(sample(d0, 5))
        
def d1():
    with open("../csv_json_coco/filename/D1.csv") as file_name:
        rows = csv.DictReader(file_name)
        d1=[]
        for row in rows:
            a=row['name']
            d1.append(a)
        
        print(sample(d1, 5))
        
def d2():
    with open("../csv_json_coco/filename/D2.csv") as file_name:
        rows = csv.DictReader(file_name)
        d2=[]
        for row in rows:
            a=row['name']
            d2.append(a)
        
        print(sample(d2, 5))

def d3():
    with open("../csv_json_coco/filename/D3.csv") as file_name:
        rows = csv.DictReader(file_name)
        d3=[]
        for row in rows:
            a=row['name']
            d3.append(a)
        
        print(sample(d3, 5))



"""
with open("../result/cluster_weight/ttma_weights.config", "r") as text_file:
    json_string = text_file.read()
    model = Sequential()
    model = model_from_json(json_string, custom_objects={'ClusteringLayer': ClusteringLayer})
    model.load_weights("../result/cluster_weight/ttma_weights.weight", by_name=False)
    
    i = predict_and_find_classify(darknet,face_image)
    i = face_image
    i = i.reshape((1, 224*224*3))
    i = np.divide(i, 255.)
    
    q = model.predict(i, verbose=0)
    y_test = q.argmax(1)
"""

def run_app():
    numpy_image = cv2.imread("../people_and_animals/face/B/B055.jpg")
    logger.info("Loading yolo model...")
    detect = Detect(metaPath=r'./facial_obj/facial.data',
                    configPath=r'./facial_obj/yolov4-tiny-custom.cfg',
                    weightPath=r'./facial_obj/weights/yolov4-tiny-custom_best.weights',
                    gpu_id=0)
    logger.info("Predicting and classifying...")
    classification, face_image = predict_and_classification_voting(detect, numpy_image)
    logger.info(f"classification result: \"{classification}\"")
    
    if classification == "A":
        model = auto_A_model()
    elif classification == "B":
        model = auto_B_model()
    elif classification == "C":
        model = auto_C_model()
    else:
        model = auto_D_model()
    
    i = face_image
    i = cv2.resize(i, dsize=(224, 224), interpolation=cv2.INTER_CUBIC)
    i = i.reshape((1, 224*224*3))
    i = np.divide(i, 255.)
    #print(i.shape)
    q = model.predict(i, verbose=0)
    y_test = q.argmax(1)
    print(y_test)
    
    if y_test == 0:
        if classification == "A":
            a0()
        elif classification == "B":
            b0()
        elif classification == "C":
            c0()
        else:
            d0()
    elif y_test == 1:
        if classification == "A":
            a1()
        elif classification == "B":
            b1()
        elif classification == "C":
            c1()
        else:
            d1()
    elif y_test == 2:
        if classification == "A":
            a2()
        elif classification == "B":
            b2()
        elif classification == "C":
            c2()
        else:
            d2()
    else:
        if classification == "A":
            a3()
        elif classification == "B":
            b3()
        elif classification == "C":
            c3()
        else:
            d3()
    
    
    #show_image_inline(face_image)
    

if __name__ == '__main__':
    logger.info("Start application")
    run_app()



    
#     queue = multiprocessing.Queue()
#     p = multiprocessing.Process(target=run_app, args=(queue,))
#     p.start()
#     p.join()
    
#     # wait until user presses enter key
#     input()
#     print(queue.get())
# +
# const
# SOURCE_DIRECTORY = "../people_and_animals/face/D/"
# EYE_DIRECTORY = "../people_and_animals/resnet_data/eye/D/"
# NOSE_DIRECTORY = "../people_and_animals/resnet_data/nose/D/"
# MOUTH_DIRECTORY = "../people_and_animals/resnet_data/mouth/D/"
# FACE_DIRECTORY = "../people_and_animals/resnet_data/face/D/"


#     create_dir_if_not_exist(EYE_DIRECTORY)
#     create_dir_if_not_exist(NOSE_DIRECTORY)
#     create_dir_if_not_exist(MOUTH_DIRECTORY)
#     create_dir_if_not_exist(FACE_DIRECTORY)

    
#    print("Start")
#    bad_detections = list()
#    for filename in os.listdir(SOURCE_DIRECTORY):
#        full_file_path = os.path.join(SOURCE_DIRECTORY, filename)
#        image = cv2.imread(full_file_path, -1)
#        if image is not None:
#            print("Handling image: " + full_file_path)
#            detections, success = save_part(detect, image, filename)
#            if not success:
#                bad_detections.append((detections, full_file_path, image))
#        else:
#            print("Skip none image path: " + full_file_path)
#    print("Done!")
#    print("Bad Detections:")
#    for detection, bad_image_name, bad_image in bad_detections:
#        print(f"----{bad_image_name}----")
#        show_image_inline(bad_image)

    #遍歷資料夾內檔案
#        for filename in os.listdir("../people_and_animals/eye/"):
#            image = cv2.imread(os.path.join("../people_and_animals/eye/", filename), -1)
        
#    if not os.path.exists(save_root):
#        os.makedirs(save_root)
#    for name in os.listdir(image_root):
#        print(name)
#        image = cv2.imread(os.path.join(image_root, name), -1)
#        draw_bbox_image = detect.predict_image(image)

    #print("main start")
    # 初始化 Detect 物件、設定 data config weights 等檔案路徑
#    detect = Detect(metaPath=r'./facial_obj/facial.data',
#                         configPath=r'./facial_obj/yolov4-tiny-custom.cfg',
#                         weightPath=r'./facial_obj/weights/yolov4-tiny-custom_best.weights',
#                         gpu_id=0)

    # 读取单张图像
#    origin_image = cv2.imread("../people_and_animals/face/C/C200.jpg")
#    detections = detect.predict_image(origin_image)
#    for detection in detections:
#        label, conf, position = detection
#        x, y, w, h = position
#        print("Label: " + str(label))
#        print("Confidence: " + str(conf))
#        print("X: " + str(x))
#        print("Y: " + str(y))
#        print("W: " + str(w))
#        print("H: " + str(h))
#        cropped_image = crop_image(origin_image, x, y, w, h)
#        show_image_inline(cropped_image)
#        print("--------------------")

#    print("Original Image:")
#    show_image_inline(origin_image)

#    print("Cropped Image:")
#    #cropped_image = crop_image(origin_image, 100, 100, 250, 150)
#    show_image_inline(cropped_image)
# -


